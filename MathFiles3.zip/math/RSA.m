(* ::Package:: *)

If[$VersionNumber < 6.0,
   NextPrime[n_Integer] := Module[{k = n},
        While[!PrimeQ[k], k++];
        Return[k]
   ]
]

AsciiToCent[x_] := Which[
   x < 33, 0,
   x < 34, 47,
   x < 48, x+47,
   x < 65, x-18,
   x < 94, x-64,
   x < 127, x-46,
   True, 0]

CentToAscii[x_] := Which[
   x < 1, 32,
   x < 30, x+64,
   x < 47, x+18,
   x < 48, 33,
   x < 81, x+46,
   x < 95, x-47,
   x == 95, 196,
   x == 96, 203,
   x == 97, 214,
   x == 98, 220,
   x == 99, 223,
   True, 32]

MessageToNumber[s_String] := Module[{total,strlist,i},
   strlist = ToCharacterCode[s];
   total = 0;
   For[i = 1, i <= Length[strlist], i++,
      total = total * 100 + AsciiToCent[ strlist[[i]] ]
   ];
   Return[total]
]

NumberToMessage[n_Integer] := Module[{Temp = n,strlist,m},
   strlist = "";
   While[Temp > 0,
      m = Mod[Temp,100];
      Temp = Quotient[Temp,100];
      strlist = FromCharacterCode[CentToAscii[m]] <> strlist;
   ];
   If[StringLength[strlist] == 0,
         strlist = FromCharacterCode[0] ];
   Return[strlist]
]
