(* ::Package:: *)

$FilledCircle = "\(CenterDot)";
If[$VersionNumber >= 3.0,
   $FilledCircle = "\[FilledSmallCircle]";
   $DefaultFont = {"Courier-New", 12}
];

If[$VersionNumber < 6.0,
   RRaster[T_] := RasterArray[T],
   RRaster[T_] := Raster[(T /. RGBColor -> List)]
]


(*  Set up DDot to be the new dot product.  *)

ResetDot := Module[{},
   ClearAttribute[Dot,Protected];
   Unprotect[Dot];
   Dot := DDot;
   ClearAll[DDot];
   DDot[x_] := x; (* OneIdentity *)
   DDot[x_ ,DDot[y_ , z_]] := DDot[DDot[x , y] , z];
   DDot[x__, y_, z_] := DDot[DDot[x , y] , z];
   DDot/: (DDot[C[a___], b_])^(-1) := (b^(-1)) . ((C[a])^(-1));
   DDot[x__,y_][z_] := DDot[x][y[z]];  (* Used to evaluate a product of cycles at a number *)
   Format[DDot[x_, y_]] := StringForm["`` \[CenterDot] ``", x, y];
   Protect[Dot];
]

InitGroup::usage =
  "InitGroup[e] initializes the group, using e as the
   identity element.  This clears any previously defined
   groups.  The dot is used to separate letters in the
   words.";

InitGroup[a_] := Module[{x, y, z, n},
  ResetDot;
  Unprotect[Power];
  ClearAttributes[Power, Protected];
  ClearAll[Power];
  DDot[z_, a] := z;
  DDot[a, z_] := z;
  DDot[z_, z_^(-1)] := a;
  DDot[z_^(-1), z_] := a;
  a^(-1) := a;
  DDot[DDot[x_ , y_], y_^(-1)] := x;
  DDot[DDot[x_ , y_^(-1)], y_] := x;
  DDot[x_ , y_]^(-1) := DDot[y^(-1), x^(-1)];
  x_^n_Integer :=
    x . (x^(n-1)) /; (n > 1) && (Head[x] =!= List);
  x_^n_Integer :=
    (x^(-1)) . (x^(n+1)) /; (n < -1) && (Head[x] =!= List);
  DDot[g_List, h_List] := Module[{i,j},
          Union[Flatten[Table[g[[i]] . h[[j]],
                        {i,Length[g]},{j,Length[h]}],1]]];
  DDot[g_List, x_] := Module[{i}, Union[Table[DDot[g[[i]], x],
                          {i, Length[g] }]] ];
  DDot[x_, g_List] := Module[{i}, Union[Table[DDot[x, g[[i]]],
                          {i, Length[g] }]] ];
  g_List^(-1) := Module[{i}, Union[Table[g[[i]]^(-1),
                          {i, Length[g] }]]];
  g_List^(n_Integer) := Module[{i}, Table[g[[i]]^n,
                        {i, Length[g] }]];
  Unprotect[OrderedQ];
  ClearAll[OrderedQ];
  OrderedQ[{P[x___Integer],P[y___Integer]}] := Module[{i},
   If[Length[P[x]] > Length[P[y]], Return[False] ];
   If[Length[P[x]] < Length[P[y]], Return[True] ];
   For[i=Length[P[x]], i>0, i--,
      If[P[x][[i]] < P[y][[i]], Return[False] ];
      If[P[x][[i]] > P[y][[i]], Return[True] ] ];
   Return[True] ];
  OrderedQ[{a,_}] := True;
  OrderedQ[{_,a}] := False;
  Protect[OrderedQ];
  Ident$ = a ]

InitRing::usage =
  "InitRing initializes a ring, clearing any previously
   defined groups or rings.  The dot is used for
    multiplication, while the plus is used for addition.";

InitRing := Module[{w,x,y,z,n,i},
   ResetDot;
   ClearAttributes[Power, Protected];
   Unprotect[Power];
   ClearAttributes[Plus, Protected];
   Unprotect[Plus];
   SetAttributes[Plus,Listable];
   Clear[Plus];
   Protect[Plus];
   ClearAll[Power];
   ClearAll[ZerosList$];
   x_^n_Integer := DDot[x, x^(n-1)] /;
                 (n > 1) && (Head[x] =!= List) && !NumberQ[x];
   DDot[g_List, h_List] := Module[{i,j},
      Union[Flatten[Table[DDot[g[[i]], h[[j]]],{i, Length[g]},
                          {j, Length[h] }], 1]]];
   DDot[g_List, x_] := Module[{i}, Union[Table[DDot[g[[i]],x],
                          {i, Length[g] }]] ];
   DDot[x_, g_List] := Module[{i}, Union[Table[DDot[x,g[[i]]],
                          {i, Length[g] }]] ];
   g_List^(-1) := Module[{i}, Union[Table[g[[i]]^(-1),
                          {i Length[g] }]]];
   DDot[x_, y_] := Expand[ x y ] /; NumberQ[x];
   DDot[x_, y_] := Expand[ x y ] /; NumberQ[y];
   DDot[x_ y_, z_] := Expand[x y z] /; (NumberQ[x] && NumberQ[y]);
   DDot[x_ y_, z_] := Expand[x DDot[y, z]] /; (NumberQ[x] && !NumberQ[y]);
   DDot[x_ y_, z_] := Expand[y DDot[x, z]] /; (NumberQ[y] && !NumberQ[x]);
   DDot[x_, y_ z_] := Expand[y DDot[x, z]] /; (NumberQ[y] && !NumberQ[x]);
   DDot[x_, y_ z_] := Expand[z DDot[x, y]] /; (NumberQ[z] && !NumberQ[x]);
   DDot[Times[Power[x_,y_],z_],w_] := (x^y) DDot[z,w] ;
   DDot[Power[x_,y_],w_] := (x^y) w /; NumberQ[x];
   DDot[x_ + y_, z_] := DDot[x, z] + DDot[y, z];
   DDot[x_, y_ + z_] := DDot[x, y] + DDot[x, z];
   For[i=1,i<=Length[UsedSymbols],i++,
      ClearAll[Evaluate[UsedSymbols[[i]]]]];
   UsedSymbols = {};
   $Post=.;
   $Char=0;
   Unprotect[OrderedQ];
   ClearAll[OrderedQ];
   OrderedQ[{P[x___Integer],P[y___Integer]}] := Module[{i},
    If[Length[P[x]] > Length[P[y]], Return[False] ];
    If[Length[P[x]] < Length[P[y]], Return[True] ];
    For[i=Length[P[x]], i>0, i--,
       If[P[x][[i]] < P[y][[i]], Return[False] ];
       If[P[x][[i]] > P[y][[i]], Return[True] ] ];
    Return[True] ];
   OrderedQ[{0,_}] := True;
   OrderedQ[{_,0}] := False;
   Protect[OrderedQ];
   LastInit$ = Ring$;
];

(*
Modout[x_] := Module[{X,yyy,z},
   X = x;
   If[$Char =!= 0,
     If[IntegerQ[X],X = Mod[X,$Char]];
     X = X /. yyy_Integer + z_ -> Mod[yyy,$Char] + z;
     If[Head[X] === Times,
        X[[0]] = List;
        If[IntegerQ[X[[1]]],X[[1]] = Mod[X[[1]],$Char]];
        X = X /. yyy_Integer * z_ -> Mod[yyy,$Char] * z;
        X[[0]] = Times,
        X = X /. yyy_Integer * z_ -> Mod[yyy,$Char] * z];
     ];
   X]


Modout[x_] := Module[{X},
X = x;
    If[$Char === 0, Return[x]];
    If[Head[X] === Times,
       X[[0]]=List;
       X = PolynomialMod[X,$Char];
       X[[0]]= Times,
       X = PolynomialMod[X, $Char]];
    Return[X]]
*)
Modout[x_] := Module[{X,ii},
X = x;
    If[$Char === 0, Return[x]];
    If[Head[X] === Times,
       X[[0]]=List,
X = {X}];
For[ii=1, ii<=Length[X],ii++,
If[Head[X[[ii]]]=!=Power,
X[[ii]] = PolynomialMod[X[[ii]],$Char],
X[[ii]] = PolynomialMod[X[[ii]][[1]], $Char]^X[[ii]][[2]]]];
X[[0]]=Times;
Return [X]]

ModDefOut[x_] := Module[{X},
   X = x;
   If[Head[X] === Rational,
      X = Numerator[X] * IInv[Denominator[X]]];
   If[IntegerQ[X],X = Mod[X,$Char]];
   X]

InitDomain[a_Integer] := Module[{x,y,z,n,i },
   $Char = Abs[a];
   If[a =!= 0,$Post = Modout, $Post=.];
   ResetDot;
   ClearAttributes[Power, Protected]
   Unprotect[Power];
   ClearAttributes[Plus, Protected]
   Unprotect[Plus];
   SetAttributes[Plus,Listable];
   Clear[Plus];
   Protect[Plus];
   ClearAll[Power];
   ClearAll[ZerosList$];
   For[i=1,i<=Length[UsedSymbols],i++,
      ClearAll[Evaluate[UsedSymbols[[i]]]]];
   g$_List^(-1) := Module[{i}, Union[Table[g$[[i]]^(-1),
                          {i Length[g$] }]]];
   UsedSymbols = {};
   DDot[x$_,y$_] := Modout[FixedPoint[Expand,x$ y$]];
   Unprotect[OrderedQ];
   ClearAll[OrderedQ];
   OrderedQ[{P[x___Integer],P[y___Integer]}] := Module[{i},
    If[Length[P[x]] > Length[P[y]], Return[False] ];
    If[Length[P[x]] < Length[P[y]], Return[True] ];
    For[i=Length[P[x]], i>0, i--,
       If[P[x][[i]] < P[y][[i]], Return[False] ];
       If[P[x][[i]] > P[y][[i]], Return[True] ] ];
    Return[True] ];
   OrderedQ[{0,_}] := True;
   OrderedQ[{_,0}] := False;
   OrderedQ[{1,_}] := True;
   OrderedQ[{_,1}] := False;
   Protect[OrderedQ];
   LastInit$ = Domain$;
   Ident$ = 1;
]

FindUnity[r_List] := Module[{i,j,TestFlag},
   For[i=1,i<=Length[r],i++,
      TestFlag = True;
      For[j=1,j<=Length[r],j++,
         If[(r[[i]] . r[[j]] =!= r[[j]]) ||
            (r[[j]] . r[[i]] =!= r[[j]]),TestFlag = False] ];
      If[TestFlag, Return[r[[i]]] ] ];
   Print["No identity element found."]
]


Define::usage =
   "Define[u, v], where u and v are words, defines the
    inference rule u -> v.  Define[F[u],v] defines the
    value of the homomorphism F at u to be v.";

Define[a_,a_] := Print["Rule already defined."]

Define[DDot[a_, b_] , c_] := Module[{},
   DDot[a, b] := c;
   DDot[DDot[z$_ , a] , b] := DDot[z$, c] ] /; UnsameQ[a . b,c]

Define[F_[a_],b_] := Module[{y},
   F[a] := b;
   If[ (F[0] =!= 0) && (Head[F[0]] =!= List),
     y = b - Flatten[{b}][[1]];
     F[0] := y ]
] /; UnsameQ[ F[a] , b ]

Define[x_Integer y_Symbol, 0] := Module[{},
   y/: z$_Integer y := Mod[z$,x] y /; (z$ < 0 || z$ >= x);
   Power/: z$_Integer y^n$_Integer := Mod[z$,x] y^n$ /; (z$ < 0 || z$ >= x);
   UsedSymbols = Union[UsedSymbols,{y}];
   DDot/: z$_Integer DDot[a$_,b$_] := Mod[z$,x] DDot[a$,b$] /;
        (MemberQ[DDot[a$,b$],y,Infinity] &&(z$ < 0 || z$ >= x))]

Define[x_Integer DDot[y_,z_], 0] := Module[{},
   DDot/: z$_Integer DDot[u$_,v$_] := Mod[z$,x] DDot[u$,v$] /;
   ((z$ < 0 || z$ >= x) &&
   ((Count[{DDot[u$,v$]},DDot[y,z],Infinity] > 0) ||
    (Count[{DDot[u$,v$]},DDot[DDot[w$_,y],z],Infinity] > 0)))
]

Define[a_^n_Integer,b_] := Module[{i},
  ClearAttribute[Power, Protected];
  Unprotect[Power];
  a^n := b;
  For[i=n+1, i <= 2n,i++,
     a^i := Evaluate[(a^(i-1)) . a]];
  a^m$_ := (a^(2n)) . (a^(m$-2n)) /; m$ > 2n] /; n > 1

RealPart[a$_] := Module[{b$},
  (a$ - J Coefficient[a$,J] - K Coefficient[a$,K]) /. Complex[x$_,_] -> x$];

InitQuaternions := Module[{i},
   ResetDot;
   ClearAttributes[Power, Protected]
   Unprotect[Power];
   ClearAttributes[Plus, Protected]
   Unprotect[Plus];
   SetAttributes[Plus,Listable];
   Clear[Plus];
   Protect[Plus];
   ClearAll[Power];
   ClearAll[J];
   ClearAll[K];
   For[i=1,i<=Length[UsedSymbols],i++,
      ClearAll[Evaluate[UsedSymbols[[i]]]]];
   UsedSymbols = {};
   $Post=.;
   $Char=0;
   DDot[a$_. Complex[b$_,c$_], d$_. Complex[e$_,f$_]] :=
                             a$ d$ (b$ + c$ I) (e$ + f$ I) /;
      ((RealPart[a$] === a$) && (RealPart[d$] === d$));
   DDot[a$_. J, b$_. J] := - a$ b$ /;
      ((RealPart[a$] === a$) && (RealPart[b$] === b$));
   DDot[a$_. K, b$_. K] := - a$ b$ /;
      ((RealPart[a$] === a$) && (RealPart[b$] === b$));
   DDot[a$_. J, b$_. K] := a$ b$ I /;
      ((RealPart[a$] === a$) && (RealPart[b$] === b$));
   DDot[a$_. K, b$_. J] := - a$ b$ I /;
      ((RealPart[a$] === a$) && (RealPart[b$] === b$));
   DDot[a$_. Complex[b$_,c$_], d$_. J] := a$ b$ d$ J + a$ c$ d$ K /;
      ((RealPart[a$] === a$) && (RealPart[d$] === d$));
   DDot[a$_. Complex[b$_,c$_], d$_. K] := a$ b$ d$ K - a$ c$ d$ J /;
      ((RealPart[a$] === a$) && (RealPart[d$] === d$));
   DDot[a$_. J, b$_. Complex[c$_,d$_]] := a$ b$ c$ J - a$ b$ d$ K /;
      ((RealPart[a$] === a$) && (RealPart[b$] === b$));
   DDot[a$_. K, b$_. Complex[c$_,d$_]] := a$ b$ c$ K + a$ b$ d$ J /;
      ((RealPart[a$] === a$) && (RealPart[b$] === b$));
   DDot[a$_ , b$_ ]:= Expand[a$ b$] /;
      ((RealPart[a$] === a$) || (RealPart[b$] === b$));
   DDot[a$_ + b$_, c$_] := DDot[a$ , c$] + DDot[b$ , c$];
   DDot[a$_ , b$_ + c$_] := DDot[a$ , b$] + DDot[a$ , c$];
   (a$_)^(-1) := Module[{w$,x$,y$,z$},
      z$ = Coefficient[a$,K];
      y$ = Coefficient[a$,J];
      x$ = a$ - y$ J - z$ K;
      w$ = x$ /. Complex[b$_,_] -> b$;
      x$ = I (w$ - x$);
      Expand[(w$ - I x$ - J y$ - K z$)/(w$ w$ + x$ x$ + y$ y$ + z$ z$)]
      ] /;
      (PolynomialQ[a$,{J,K}] && (Not[FreeQ[a$,J]] || Not[FreeQ[a$,K]]));
   Protect[Dot,Power];
   $StringOrder = {"I","J","K",{"a","A"},{"b","B"},{"c","C"},{"d","D"},
                   {"e","E"},{"f","F"},{"g","G"},{"h","H"},"i","j","k",
                   {"l","L"},{"m","M"},{"n","N"},{"o","O"},{"p","P"},
                   {"q","Q"},{"r","R"},{"s","S"},{"t","T"},{"u","U"},
                   {"v","V"},{"w","W"},{"x","X"},{"y","Y"},{"z","Z"},
                   "0","1","2","3","4","5","6","7","8","9"};
   Unprotect[OrderedQ];
   ClearAll[OrderedQ];
   OrderedQ[{P[x___Integer],P[y___Integer]}] := Module[{i},
    If[Length[P[x]] > Length[P[y]], Return[False] ];
    If[Length[P[x]] < Length[P[y]], Return[True] ];
    For[i=Length[P[x]], i>0, i--,
       If[P[x][[i]] < P[y][[i]], Return[False] ];
       If[P[x][[i]] > P[y][[i]], Return[True] ] ];
    Return[True] ];
   OrderedQ[{0,_}] := True;
   OrderedQ[{_,0}] := False;
   Protect[OrderedQ];
   LastInit$ = Quaternions$;
];

Homomorph::usage =
   "Homomorph[F] defines F to be a homomorphism between two
    rings M and K.";

Homomorph[F$_Symbol] := Module[{},
   UsedSymbols = Union[UsedSymbols,{F$}];
   ClearAll[Evaluate[F$]];
   F$[DDot[a$_ , b$_]] := DDot[F$[a$] , F$[b$]] + F$[0] - F$[0];
   F$[a$_ b$_] := DDot[F$[a$] , F$[b$]] + F$[0] - F$[0];
   F$[a$_ + b$_] := F$[a$] + F$[b$];
   F$[a$_ ^ b$_Integer] := FixedPoint[Expand, F$[a$]^b$] + F$[0] - F$[0];
   F$[a$_Integer /; a$ =!= 0] := a$;
   F$[a$_Rational /; a$ =!= 0] := a$;
   F$[{a$_}] := { F$[a$] };
   F$[{a$__,b$_}] := Union[F$[{a$}],{F$[b$]}]];

SetAttributes[Homomorph, HoldAll];

Kernel::usage =
   "Kernel[F,G] finds the kernel of the homomorphism F whose
    domain is G.";

Kernel[F_,G_] := Module[{g,k,i},
   g = Union[G];
   k = {};
   Do[ If[MemberQ[Flatten[{F[G[[i]] ]}],0],
          k = Append[k,g[[i]] ] ], {i,1,Length[g]}];
   Return[k] ]

HomoInverse::usage =
   "HomoInverse[F,S,G] takes the inverse homomorphism F,
    whose domain is G, of the element or set of elements S.";

HomoInverse[F_,S_,G_] := Module[{g,k,i},
   g = Union[G];
   k = {};
   Do[ If[Intersection[Flatten[{S}],Flatten[{F[g[[i]]]}]] != {},
          k = Append[k,g[[i]] ] ], {i,1,Length[g]}];
   Return[k] ]

CheckHomo::usage = "CheckHomo[F,D] verifies that F is a homomorphism
   with a domain of D.";

CheckHomo[f_,D_List] := Module[{i,j},
   For[i=Length[D], i>0, i--,
      For[j=Length[D], j>0, j--,
         If[ DDot[f[D[[i]]] , f[D[[j]]]] + f[0] =!= f[DDot[D[[i]],D[[j]]] ],
            Print["f[",D[[i]],"] . f[",D[[j]],
                 "] is not equal to f[", DDot[D[[i]] , D[[j]]],"]"];
            Return[False] ];
         If[ f[D[[i]]] + f[D[[j]]] =!= f[D[[i]] + D[[j]] ],
            Print["f[",D[[i]],"] + f[",D[[j]],
                 "] is not equal to f[", D[[i]] + D[[j]],"]"];
            Return[False] ] ] ];
   Return[True] ]

Define[a_^(-1) , b_] := a^(-1) := b;

ClearDefs::usage =
   "ClearDefs  resets the dot product, erasing all rings and domains.";

ClearDefs := Module[{j},
   ResetDot;
   ClearAttributes[Power, Protected]
   Unprotect[Power];
   ClearAttributes[Plus, Protected]
   Unprotect[Plus];
   Unprotect[OrderedQ];
   SetAttributes[Plus,Listable];
   Clear[Plus];
   Protect[Plus];
   ClearAll[Power];
   ClearAll[OrderedQ];
   g_List^(n_Integer) := Module[{i}, Table[g[[i]]^n,
                         {i,Length[g] }]];
   OrderedQ[{P[a___Integer],P[b___Integer]}] := Module[{i},
   If[Length[P[a]] > Length[P[b]], Return[False] ];
   If[Length[P[a]] < Length[P[b]], Return[True] ];
   For[i=Length[P[a]], i>0, i--,
      If[P[a][[i]] < P[b][[i]], Return[False] ];
      If[P[a][[i]] > P[b][[i]], Return[True] ] ];
   Return[True] ];
   For[j=1,j<=Length[UsedSymbols],j++,
      ClearAll[Evaluate[UsedSymbols[[j]]]]];
   UsedSymbols = {};
   $Post=.;
   $Char=0;
   LastInit$=.
   Protect[Dot, Power, OrderedQ]; ]

Group::usage =
   "Group[X_List] gives a list of elements of the group
    symbolically presented by the set of generators X and
    the inference rules previously defined.";

Group[G_List] := Module[{m, n, i, j, g, Repeat},
   g = Union[G];
   m = Length[g];
   Repeat = True;
   While[Repeat,
      Repeat = False;
      n = Length[g];
      Do[ Do[ If[ MemberQ[g, DDot[g[[i]], g[[j]]] ],Null,
                  Repeat = True;
                  g = Append[g, DDot[g[[i]], g[[j]]] ]
                ], {i,1,n} ], {j,1,m} ] ];
   Sort[g] ]

Group[a_Symbol] := Group[{a}]

AddGroup[G_List] := Module[{m, n, i, j, g, Repeat},
   g = Union[G];
   m = Length[g];
   Repeat = True;
   While[Repeat,
      Repeat = False;
      n = Length[g];
      Do[ Do[ If[ MemberQ[g, Modout[g[[i]] + g[[j]]] ],Null,
                  Repeat = True;
                  g = Append[g, Modout[g[[i]] + g[[j]]] ]
                ], {i,1,n} ], {j,1,m} ] ];
   Sort[g] ]

Ring[R_List] := Module[{m, n, i, j, g, Temp, Repeat},
   If[Not[MemberQ[{Field$,Ring$,Domain$},LastInit$]],
      Print["Ring has not been initialized."],
      g = Union[R];
      m = Length[g];
      Repeat = True;
      While[Repeat,
         Repeat = False;
         n = Length[g];
         Do[ Do[
            Temp = DDot[g[[j]] , g[[i]]];
            If[ MemberQ[g, Temp],Null,
               Repeat = True;
               AppendTo[g, Temp ] ];
            Temp = Modout[g[[i]] + g[[j]]];
            If[ MemberQ[g, Temp ],Null,
               Repeat = True;
               AppendTo[g, Temp ] ]  , {i,1,n} ], {j,1,m} ] ];
      Sort[g] ]]

Ring[a_Symbol] := Ring[{a}]

RootCount::usage =
   "RootCount[G_List, k_Integer] gives the number of solutions to x^k = e in G";
    
RootCount[G_List, k_Integer] := Module[{i,j,t, count},
         count = 0;
         For[i=1, i<= Length[G], i++,
             t = G[[i]];
             For[j = 1, j <= k, j++,
                 t = t . G[[i]]
             ];
             If[t == G[[i]], count++]
         ];
         count]
         
ToStr[x_] := StringJoin[Select[Characters[ToString[
             If[MemberQ[ToCharacterCode[ToString[x]],10],InputForm[x],x]
             ]],# =!= " " &]]

ColorTable := {RGBColor[0,0,0],
               RGBColor[1,1,0],RGBColor[1,0,1],RGBColor[0,1,1],
               RGBColor[1,0,0],RGBColor[0,1,0],RGBColor[.6,.4,.8],
               RGBColor[1,.6,0],RGBColor[.7,.8,.7],RGBColor[.8,.6,.5],
               RGBColor[.5,.6,.8],RGBColor[.8,.2,.5],RGBColor[.8,.6,.2],
               RGBColor[.6,.6,.2],RGBColor[1,.4,.4],RGBColor[.2,.8,.7],
               RGBColor[1,.6,1],RGBColor[.7,1,0],RGBColor[0,0,1],
               RGBColor[.6,.4,.4],RGBColor[0,.6,1],RGBColor[1,.8,.7],
               RGBColor[.4,.2,1],RGBColor[1,.8,.4],RGBColor[.2,.6,.4],
               RGBColor[.5,.8,.8],RGBColor[.4,.8,.5],RGBColor[0,1,.6],
               RGBColor[.8,.5,.2],RGBColor[.2,.2,.9]};

SubSetPosition[Q_List,S_] := Module[{i,j},
   If[Head[S] === List,
      j = 0;
      For[i=1,i<=Length[Q],i++,
        If[Complement[S,Q[[i]]] === {}, j = i; i = Length[Q]]],
      If[MemberQ[Q,S],j = Position[Q,S,1][[1]][[1]], j=0]];
   j];

QuotientRing = False;

MultTable::usage =
   "MultTable[X_List] gives a multiplication table of the elements
    in the list, using different colors for different elements.
    The list can have no more than 27 elements.";
CayleyTable::usage = "Alias for MultTable";

MultTable[Q_List] := Module[{i,j,T,Z},
   If[Length[Q] > 27, Print["Group too big to print table."],
     If[QuotientRing,Z = Q[[1]] - Q[[1]],Z=0];
     T = Table[
      If[i===0,
     If[j===0,RGBColor[1,1,1],ColorTable[[j+1]]],
      If[j===0,ColorTable[[i+1]],
       ColorTable[[SubSetPosition[Q,
         If[(LastInit$ === Domain$) && (Not[MemberQ[{P,C},Head[Q[[1]]]]]),
            Modout[FixedPoint[Expand,Q[[i]] Q[[j]]]],
            DDot[Q[[i]],Q[[j]]]]
         ]+1]]]],
         {i,Length[Q],0,-1},{j,0,Length[Q]}];
       If[Max[Table[Length[Characters[ToStr[Q[[i]]]]],
          {i,1,Length[Q]}]]*(Length[Q]+1) < 85,
      Show[Graphics[RRaster[T]],
          Graphics[Text[StyleForm["\[CenterDot]",FontSize->18],{.5,Length[Q]+.5}]],
          Graphics[Table[
         Text[StyleForm[ToStr[Q[[i]]],FontSize->18],{i+.5,Length[Q]+.5}],{i,1,Length[Q]}]],
         Graphics[Table[
         Text[StyleForm[ToStr[Q[[j]]],FontSize->18],{.5,Length[Q] - j + .5}],{j,1,Length[Q]}]],
         Graphics[Table[
         Text[If[SubSetPosition[Q,
         If[LastInit$ === Domain$,
            Modout[FixedPoint[Expand,Q[[i]] Q[[j]]]],
            DDot[Q[[i]],Q[[j]]]]] > 0,StyleForm[ToStr[
         If[LastInit$ === Domain$,
            Modout[FixedPoint[Expand,Q[[i]] Q[[j]]]],
            DDot[Q[[i]],Q[[j]]]]+Z],FontSize->18]," "],
           {j + .5, Length[Q] - i + .5}],
            {i,1,Length[Q]},{j,1,Length[Q]}]],
         Graphics[Line[{{1,0},{1,Length[Q]},{Length[Q]+1,Length[Q]}}]]],
    Show[Graphics[RRaster[T]],
         Graphics[Text[StyleForm["\[CenterDot]",FontSize->18],{.5,Length[Q]+.5}]],
         Graphics[Table[
    Text[StyleForm[ToStr[Q[[i]]],FontSize->18],{-.5,Length[Q] - i + .5},{1,0}],{i,1,Length[Q]}]],
         Graphics[Line[{{1,0},{1,Length[Q]},{Length[Q]+1,Length[Q]}}]],
         AspectRatio -> Automatic,
         PlotRange -> All]]]]
         
CayleyTable[Q_List] := MultTable[Q]

AddTable::usage =
   "AddTable[X_List] gives a addition table of the elements
    in the list, using different colors for different elements.
    The list can have no more than 27 elements.";

AddTable[Q_List] := Module[{i,j,T},
   If[Length[Q] > 27, Print["Group too big to print table."],
     T = Table[
      If[i===0,
     If[j===0,RGBColor[1,1,1],ColorTable[[j+1]]],
      If[j===0,ColorTable[[i+1]],
       ColorTable[[SubSetPosition[Q,Modout[Q[[i]] + Q[[j]]]]+1]]]],
         {i,Length[Q],0,-1},{j,0,Length[Q]}];
       If[Max[Table[Length[Characters[ToStr[Q[[i]]]]],
          {i,1,Length[Q]}]]*(Length[Q]+1) < 85,
      Show[Graphics[RRaster[T]],
          Graphics[Text[StyleForm["+",FontSize->18],{.5,Length[Q]+.5}]],
          Graphics[Table[
         Text[StyleForm[ToStr[Q[[i]]],FontSize->18],{i+.5,Length[Q]+.5}],{i,1,Length[Q]}]],
         Graphics[Table[
         Text[StyleForm[ToStr[Q[[j]]],FontSize->18],{.5,Length[Q] - j + .5}],{j,1,Length[Q]}]],
         Graphics[Table[
         Text[If[MemberQ[Q,Modout[Q[[i]]+Q[[j]]]],
                           StyleForm[ToStr[Modout[Q[[i]]+Q[[j]]]],FontSize->18]," "],
           {j + .5, Length[Q] - i + .5}],
            {i,1,Length[Q]},{j,1,Length[Q]}]],
         Graphics[Line[{{1,0},{1,Length[Q]},{Length[Q]+1,Length[Q]}}]]],
    Show[Graphics[RRaster[T]],
         Graphics[Text[StyleForm["+",FontSize->18],{.5,Length[Q]+.5}]],
         Graphics[Table[
    Text[StyleForm[ToStr[Q[[i]]],FontSize->18],{-.5,Length[Q] - i + .5},{1,0}],{i,1,Length[Q]}]],
         Graphics[Line[{{1,0},{1,Length[Q]},{Length[Q]+1,Length[Q]}}]],
         AspectRatio -> Automatic,
         PlotRange -> All]]]]

AArrow[Color_,{{x1_,y1_},{x2_,y2_}}] := Module[{dx,dy,Len},
    dx = x2-x1;
    dy = y2-y1;
    Len = N[Sqrt[dx N[dx] + dy N[dy]]];
    If[Len + 0. =!= 0. ,
     {Color,Line[{{N[x1],N[y1]},{N[x2],N[y2]}}],
      Polygon[{{N[x2],N[y2]},
          {N[x2-(.1 dx + .05 dy)/Len],
              N[y2-(.1 dy - .05 dx)/Len]},
          {N[x2-(.1 dx - .05 dy)/Len],
              N[y2-(.1 dy + .05 dx)/Len]}}]},
     Len = N[Sqrt[2 x2 N[x2] + 2 y2 N[y2]]];
     dx = x2/Len;
     dy = y2/Len;
     {Color,Line[
 {{N[x2 - .1 dy - .1 dx],N[y2 + .1 dx - .1 dy]},
  {N[x2 - .1307 dy - .1459 dx],N[y2 + .1307 dx - .1459 dy]},
  {N[x2 - .2 dx - .1414 dy],N[y2 - .2 dy + .1414 dx]},
  {N[x2 - .1307 dy - .2541 dx],N[y2 + .1307 dx - .2541 dy]},
  {N[x2 - .1 dy - .3 dx],N[y2 + .1 dx - .3 dy]},
  {N[x2 - .0541 dy - .3307 dx],N[y2 + .0541 dx - .3307 dy]},
  {N[x2 - .3413 dx],N[y2 - .3414 dy]},
  {N[x2 + .0541 dy - .3307 dx],N[y2 - .0541 dx - .3307 dy]},
  {N[x2 + .1 dy - .3 dx],N[y2 - .1 dx - .3 dy]},
  {N[x2 + .1307 dy - .2541 dx],N[y2 - .1307 dx - .2541 dy]},
  {N[x2 - .2 dx + .1414 dy],N[y2 - .2 dy - .1414 dx]},
  {N[x2 + .1307 dy - .1459 dx],N[y2 - .1307 dx - .1459 dy]},
  {N[x2 + .1 dy - .1 dx],N[y2 - .1 dx - .1 dy]},
  {N[x2],N[y2]}}],
      Polygon[{{N[x2],N[y2]},
          {N[x2 -.15 dy -.05 dx],N[y2 + .15 dx -.05 dy]},
          {N[x2 -.05 dy -.15 dx],N[y2 + .05 dx -.15 dy]}}]}]
    ]

CircleGraph[G_,F_] := Module[{T,L,n,i,j,k,m,Q,S},
   S = ToStr[Hold[G]];
   m = StringPosition[S,{"{",",","}"}];
   If[m === {},
     S = ToStr[ReleaseHold[G]];
     m = StringPosition[S,{"{",",","}"}] ];
   L = Length[G];
   If[m === {}, L = 0];
   T = {};
   For[i=1,i<=L,i++,
      If[Position[T,i] === {},
         Q = {i};
         j = Position[ReleaseHold[G],ReleaseHold[F[G[[i]]]]];
         If[j==={},j=i,j=j[[1]][[1]]];
         While[Position[Union[Q,T],j]==={},
           AppendTo[Q,j];
           j = Position[ReleaseHold[G],ReleaseHold[F[G[[j]]]]];
           If[j==={},j=i,j=j[[1]][[1]]]];
         AppendTo[T,Q]]];
   Show[Graphics[{{ColorTable[[4]],Circle[{0,0},1]},
     Table[Text[StyleForm[$FilledCircle,FontSize->18],
        {Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},{.1,0}],{n,1,L}],
     Text[StyleForm[StringTake[S,{m[[1]][[1]]+1,m[[2]][[1]]-1}],FontSize->18],{0,1.1},{0,-1}],
     If[EvenQ[L],Text[StyleForm[StringTake[S,{m[[1 + Quotient[L,2]]][[1]]+1,
                                    m[[2 + Quotient[L,2]]][[1]]-1}],FontSize->18],
                                         {0,-1.1},{0,1}],{}],
     Table[Text[StyleForm[StringTake[S,{m[[n+1]][[1]]+1,m[[n+2]][[1]]-1}],FontSize->18],
         {Sin[2 Pi n/N[L]]*1.1,Cos[2 Pi n/N[L]]*1.1},{-1,0}],
                         {n,1,Quotient[L-1,2]}],
     Table[Text[StyleForm[StringTake[S,{m[[n+1]][[1]]+1,m[[n+2]][[1]]-1}],FontSize->18],
          {Sin[2 Pi n/N[L]]*1.1,Cos[2 Pi n/N[L]]*1.1},{1,0}],
                         {n,Quotient[L+2,2],L-1}],
     Table[
       Table[n = T[[k]][[j]]-1;
             i = Position[ReleaseHold[G],ReleaseHold[F[G[[n+1]]]]];
              If[i === {},
                 {Text[StyleForm["?",FontSize->18, FontWeight->"Bold"],{0,0}],
                  AArrow[ColorTable[[4+k]],
                   {{Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},
              {.1 Sin[2 Pi n/N[L]], .1 Cos[2 Pi n/N[L]]}}]},
                  i = i[[1]][[1]]-1;
             AArrow[ColorTable[[4+k]],
               {{Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},
                  {Sin[2 Pi i/N[L]],Cos[2 Pi i/N[L]]}}]],
                                   {j,1,Length[T[[k]]]}],
                                           {k,1,Length[T]}]},
     AspectRatio -> Automatic,PlotRange->All]]]

SetAttributes[CircleGraph, HoldFirst];

Add[x_] := # + x&;

Mult[x_] := x . #&;

LeftMult[x_] := # . x&;

RightMult[x_] := x . #&;

Inv := IInv[#]&;

Pow[x_] := #^x&;

GraphHomo[F_,G_List] := Module[{g,L,d,i,M,p},
  L = Length[G];
  d = {};
  p = {};
  If[ L > 1,
     For[i=1, i<=L, i++,
        t = Position[d,F[G[[i]]],1];
        If[t === {},
           AppendTo[d,F[G[[i]]]];
           AppendTo[p,Length[d]],
           AppendTo[p,t[[1]][[1]]]
          ]
         ];
     M = Length[d];
     Show[Graphics[{
         {ColorTable[[4]],Line[{{0,0},{0,1}}]},
         {ColorTable[[4]],Line[{{1,0},{1,1}}]},
         Table[Text[StyleForm[$FilledCircle,FontSize->18],
              {0,i/N[L-1]}],{i,0,L-1}],
         Table[Text[StyleForm[ToStr[G[[i]]],FontSize->18],{-0.1,(L-i)/N[L-1]},{1,0}],
              {i,1,L}],
         If[M === 1,
            p = Table[2,{i,1,L}];
            M = 3;
            {Text[StyleForm[$FilledCircle,FontSize->18],{1,.5}],
             Text[StyleForm[ToStr[d[[1]]],FontSize->18],{1.1,0.5},{-1,0}]},
            {Table[Text[StyleForm[$FilledCircle,FontSize->18],
              {1,i/N[M-1]}],{i,0,M-1}],
            Table[Text[StyleForm[ToStr[d[[i]]],FontSize->18],{1.1,(M-i)/N[M-1]},{-1,0}],
              {i,1,M}]}],
         Table[AArrow[ColorTable[[4 + p[[i]]]],
              {{0,(L-i)/N[L-1]},{1,(M-p[[i]])/N[M-1]}}],
              {i,1,L}]
   },AspectRatio -> Automatic, PlotRange -> All]]
]]

ToVector[Q_] := Module[{i,L,X,T},
  X = Expand[Q];
  If[Head[X] =!= Plus, X = {X}];
  L = Length[X];
  T = {};
  For[i=1,i<=L,i++,
    If[NumberQ[X[[i]]],
      If[Head[X[[i]]] === Complex,
        If[Re[X[[i]]] =!= 0,AppendTo[T,{Re[X[[i]]],1}]];
        AppendTo[T,{Im[X[[i]]],I}],
        AppendTo[T,{X[[i]],1}]],
      If[Head[X[[i]]] =!= Times,AppendTo[T,{1,X[[i]]}],
         If[NumberQ[X[[i]][[1]]],
           AppendTo[T,{X[[i]][[1]],X[[i]]/X[[i]][[1]]}],
           AppendTo[T,{1,X[[i]]}]
           ]
         ]
       ]
      ];
   T]

ToBasis[K_, B_List] := 
 Module[{KK, i, j, T, M, Vars, Q, QQ, Y, Z, TT, k},
  KK = K;
  Vars = {};
  If[Head[KK] =!= List, KK = {K}];
  T = Table[
    Expand[KK[[i]]*B[[j]]], {i, 1, Length[KK]}, {j, 1, Length[B]}];
  T = Flatten[T, 1];
  (* First identify all of the atoms in the B list *)
       For[j = 1, j <= Length[T], j++,
   If[Head[T[[j]] ] =!= List, 
    Vars = Union[Vars, Transpose[ToVector[T[[j]]]][[2]]],
    For[i = 1, i <= Length[T[[j]]], i++,
     Vars = Union[Vars, Transpose[ToVector[T[[j]][[i]]]][[2]]]]]];
  Q = {};
  For[i = 1, i <= Length[T], i++,
   TT = T[[i]];
   If[Head[TT] =!= List, TT = {TT}];
   QQ = {};
   For[k = 1, k <= Length[TT], k++,
    Y = ToVector[TT[[k]]];
            Z = Table[0, {j, 1, Length[Vars]}];
            
    For[j = 1, j <= Length[Y], j++,    
     Z[[Position[Vars, Y[[j]][[2]]][[1]][[1]]]] = Y[[j]][[1]]];
    QQ = Join[QQ, Z];
    ];
          AppendTo[Q, QQ]];
  If[NumberQ[$Char] && $Char > 0,
   Q = RowReduce[Q, Modulus -> $Char], 
   Q = RowReduce[Q]];
  (* check that the last row is not 0 *)
  If[Union[Q[[-1]]] == {0},
   Print["Error: linearly dependent."];
   Return[ False],
   Return[Basis[K, B]]]
  ]
  
  
Coefficients[BB_Basis, NN_] := 
 Module[ {i, j, T, M, Q, QQ, Y, Z, TT, L, k},
  KK = BB[[1]];
  B = BB[[2]];
  Vars = {};
  If[Head[KK] =!= List, KK = {KK}];
  T = Table[
    Expand[KK[[i]]*B[[j]]], {i, 1, Length[KK]}, {j, 1, Length[B]}];
  T = Flatten[T, 1];
  AppendTo[T, NN];
  (* First identify all of the atoms in the B list *)
       For[j = 1, j <= Length[T], j++,
   If[Head[T[[j]] ] =!= List, 
    Vars = Union[Vars, Transpose[ToVector[T[[j]]]][[2]]],
    For[i = 1, i <= Length[T[[j]]], i++,
     Vars = Union[Vars, Transpose[ToVector[T[[j]][[i]]]][[2]]]]]];
  Q = {};
  For[i = 1, i <= Length[T], i++,
   TT = T[[i]];
   If[Head[TT] =!= List, TT = {TT}];
   QQ = {};
   For[k = 1, k <= Length[TT], k++,
    Y = ToVector[TT[[k]]];
            Z = Table[0, {j, 1, Length[Vars]}];
            
    For[j = 1, j <= Length[Y], j++,    
     Z[[Position[Vars, Y[[j]][[2]]][[1]][[1]]]] = Y[[j]][[1]]];
    QQ = Join[QQ, Z];
    ];
          AppendTo[Q, QQ]];
  (* ready to solve the equations *)
  Q = Transpose[Q];
  If[NumberQ[$Char] && $Char > 0, 
   Q = RowReduce[Q, Modulus -> $Char], 
   Q = RowReduce[Q]];
  M = Length[T];
  L = Length[Q];
  QQ = {};
  i = 1;
  For[j = 1, j < M, j++, 
    If[(i > L) || (Q[[i, j]] === 0), AppendTo[QQ, 0], 
     AppendTo[QQ, Q[[i, M]]];
     i++]];
  (* convert QQ to the original elements *)
  Z = Table[0, {i, 1, Length[B]}];
  For[k = 1, k <= Length[KK], k++,
    For[j = 1, j <= Length[B], j++,
     Z[[j]] = Z[[j]] + KK[[k]]*QQ[[j + (k - 1)*Length[B]]]]];
  If[(i > L) || Q[[i, M]] === 0, Z, NotInSpan]
]
  
Vectorize[x_,y_List] := Module[{i,j,Y,M,L,Q,T,Z,Vars},
  Vars = {};
  Y =  Append[y,x];
  M = Length[Y];
  For[j=1,j<=M,j++,
     Vars = Union[Vars,Transpose[ToVector[Y[[j]]]][[2]]]];
  L = Length[Vars];
  Q = {};
  For[i=1,i<=M,i++,
     T = ToVector[Y[[i]]];
     Z = Table[0,{j,1,L}];
     For[j = 1, j <= Length[T], j++,
        Z[[Position[Vars,T[[j]][[2]]][[1]][[1]]]] = T[[j]][[1]]];
     AppendTo[Q,Z] ];
  Q = RowReduce[Transpose[Q]];
  T = {};
  i=1;
  For[j = 1,j < M,j++,
     If[(i>L)||(Q[[i,j]] === 0),
        AppendTo[T,0],
        AppendTo[T,Q[[i,M]]];
        i++]];
  If[(i>L)||Q[[i,M]] === 0, T , NotInSpan]
]

GeneratorReduce[Basis_List] := Module[{i,j},
  Bas = Union[DeleteCases[Basis,0]];
  M = Length[Bas];
  Vars = {};
  For[j=1,j<=M,j++,
     Vars = Union[Vars,Transpose[ToVector[Bas[[j]]]][[2]]]];
  L = Length[Vars];
  T = Table[Vectorize[Bas[[j]],Vars],{j,1,M}];
  If[(Flatten[DeleteCases[T, _Integer,2]] === {}) &&
    (Length[Union[Bas,Vars]]===M), Bas = Vars];
  Bas
]

CheckGroup[G_List] := Module[{i,j,k,n,m,L,T,U,Test},
  g = Union[G];
  L = Length[g];
  Test = True;
  For[i=1,i<=L,i++,
    T = Union[Table[DDot[g[[i]] , g[[j]]],{j,1,L}]];
    U = Union[Table[DDot[g[[j]] , g[[i]]],{j,1,L}]];
    If[(T =!= g) || (U =!= g), Test = False]
  ];
  If[Test === False,
    Print["The Latin square property does not hold for this set."],
    For[i=1,i<=L,i++,
       For[j=1,j<=L,j++,
          For[k=1,k<=L,k++,
             m = DDot[g[[i]], g[[j]]];
             n = DDot[g[[j]], g[[k]]];
             If[DDot[m , g[[k]]] =!= DDot[g[[i]], n],
                  Print[g[[i]], " . (", g[[j]]," . ", g[[k]],
                        ") is not equal to (",g[[i]]," . ",g[[j]],
                        ") . ",g[[k]]];
                  Test = False]]]];
    If[Test,
       Print["This set of elements is a group."],
       Print["Associtive Property does not hold."]]]];

CheckRing[Bas_List] := Module[{i,j,k,n,m,L,T,Basis},
  If[LastInit$ === Quaternions$,
    Print["The Quaternions are the first known example of a skew field."],
    If[Not[MemberQ[{Ring$,Domain$,Quaternions$},LastInit$]],
      Print["The ring is not yet initialized!"],
      Basis = GeneratorReduce[Bas];
      L = Length[Basis];
      T = Table[Vectorize[DDot[Basis[[i]],Basis[[j]]],Basis],{i,1,L},{j,1,L}];
      If[Flatten[DeleteCases[T, _Integer, 3]] =!= {},
        Print["Ring is not closed under multiplication."],
        Vars = {};
        For[j=1,j<=L,j++,
          Vars = Union[Vars,Transpose[ToVector[Basis[[j]]]][[2]]]];
        L = Length[Vars];
        Chars = {};
        For[j=1,j<=L,j++,
          AppendTo[Chars,
             If[MemberQ[{1,I},Vars[[j]]],0,
                Coefficient[ - Vars[[j]],Vars[[j]]] + 1]]];
        T = True;
        For[i=1,i<=L,i++,
          For[j=1,j<=L,j++,
            k = DDot[Vars[[i]], Vars[[j]]];
            If[Expand[Chars[[i]] k] =!= 0,
              Print[Chars[[i]]," . (", Vars[[i]]," . ",Vars[[j]],
                    ") is not equal to (",Chars[[i]],Vars[[i]],
                    ") . ",Vars[[j]]];
              T = False];
            If[Expand[Chars[[j]] k] =!= 0,
              Print[Chars[[j]]," . (", Vars[[i]]," . ",Vars[[j]],
                    ") is not equal to ",Vars[[i]],
                    " . (",Chars[[j]],Vars[[j]],")"];
              T = False]]];
        If[Not[T],
          Print["Distributive Property does not hold."],
          For[i=1,i<=L,i++,
            For[j=1,j<=L,j++,
              For[k=1,k<=L,k++,
                m = DDot[Vars[[i]], Vars[[j]]];
                n = DDot[Vars[[j]], Vars[[k]]];
                If[DDot[m , Vars[[k]]] =!= DDot[Vars[[i]], n],
                  Print[Vars[[i]], " . (", Vars[[j]]," . ",Vars[[k]],
                        ") is not equal to (",Vars[[i]]," . ",Vars[[j]],
                        ") . ",Vars[[k]]];
                  T = False]]]];
          If[T,
            Print["These elements will generate a ring."],
            Print["Associtive Property does not hold."]]]]]]];

CheckField[Bas_List] := Module[
              {Basis,L,T,i,j,k,M,m,Vars,Big,BigInverse,Id,Determ},
   Basis = GeneratorReduce[Bas];
   L = Length[Basis];
   If[Not[MemberQ[{Ring$,Domain$,Quaternions$},LastInit$]],
      Print["Addition is not even defined yet!"],
      T = Table[Vectorize[DDot[Basis[[i]],Basis[[j]]],Basis],{i,1,L},{j,1,L}];
      If[Position[T,NotInSpan] =!= {},
         Print["Additive group generated is not closed under multiplication."],
         Vars = {};
         For[j=1,j<=L,j++,
            Vars = Union[Vars,Transpose[ToVector[Basis[[j]]]][[2]]]];
         If[LastInit$ === Domain$, M = $Char,
            M = Union[Table[
               If[MemberQ[{1,I},Vars[[j]]],0,
                  Coefficient[ - Vars[[j]],Vars[[j]]] + 1],
                            {j,1,Length[Vars]}]];
            If[Length[M] =!= 1, M = -1,M = M[[1]] ]];
         If[M === -1 || (M > 0 && Not[PrimeQ[M]]),
           If[M === -1,
             Print["Not all of the elements are the same additive order, "],
             Print["The additive order of the elements is not a prime number, "]];
           Print["so this cannot be a field."];
           If[Transpose[T] === T,
             Print["This is a Commutative Ring."],
             Print["This is a Non-commutative Ring."]],
           Big = {};
           For[i=1,i<=L,i++,
              Big = Union[Big,
                Transpose[Append[T[[i]],Table[If[j==i,1,0],{j,1,L}]]]];
              Big = Union[Big,
                Transpose[Append[
                     Transpose[T][[i]],Table[If[j==i,1,0],{j,1,L}]]]]];
           AppendTo[Big,Table[0,{j,0,L}]];
           Big = RowReduce[Big, Modulus -> M];
           If[Big[[L+1]][[L+1]] =!= 0,
              If[Transpose[T] === T,
                 Print["Commutative Ring without an identity element."],
                 Print["Non-commutative Ring without an identity element."]],
              Id = Take[Transpose[Big][[L+1]],L];
              If[M > 0,
                 For[j=1,j<=L,j++,
                  Id[[j]] = Mod[ Id[[j]] * PowerMod[Big[[j]][[j]],-1,M],M]]];
              Print["Identity element = ",
                     Expand[Sum[Id[[i]] Basis[[i]],{i,1,L}]]];
              Big = Table[Sum[T[[i]][[j]][[k]]*C[j],{j,1,L}],{i,1,L},{k,1,L}];
              Determ = Factor[PolynomialMod[Det[Big],M]];
              Print["An element is invertable as long as ",Determ,
                                                    " is not zero."," "];
              If[M > 0,
                 For[j=1,j<=L+1,j++,m[j] = 0];
                 m[1] = 1;
                 j = 1;
                 TestFlag := True;
                 While[j <= L,
                   If[Mod[Determ /. Table[C[i] -> m[i],{i,1,L}],M] === 0,
                      TestFlag := False;
                      Print[Expand[Sum[m[i] Basis[[i]],{i,1,L}]],
                         " is not invertable."]];
                   j = 1;
                   m[j]++;
                   While[m[j] === M, m[j] = 0; j++; m[j]++]
                 ];
                 If[TestFlag,
                    If[Transpose[T] === T,
                       Print["This is a field."],
                       Print["This is a skew field."]],
                    If[Transpose[T] === T,
                       Print["This is only a communitive ring with identity."],
                       Print["This is only a non-communitive ring with identity."]]],
                 If[Transpose[T] === T,
                    Print["If the only element which is not invertable is 0,",
                          " then this is a field."," "],
                    Print["If the only element which is not invertable is 0,",
                          " then this is a skew field."," "]]];
              BigInverse = 0;
              For[i=1,i<=L,i++,
                 T = Big;
                 T[[i]] = Id;
                 BigInverse = BigInverse + Basis[[i]] Det[T]
              ];
              If[M===0,
                BigInverse = Factor[BigInverse / Determ];
                If[LastInit$ =!= Quaternions$,
                    ClearAttributes[Power, Protected];
                    Unprotect[Power];
                   (z$_)^(-1) := Module[{x,y,l},
                     x = Vectorize[z$,Basis];
                     y = Table[C[l] -> x[[l]],{l,1,Length[Basis]}];
                     BigInverse /. y
                     ] /; Not[NumberQ[z$]] && Vectorize[z$,Basis] =!= NotInSpan;
                ];
                Print["The inverse of ", Sum[ C[i] Basis[[i]],{i,1,L}],
                   " is given by ",BigInverse],
                BigInverse = PolynomialMod[BigInverse,M];
                ClearAttributes[Power, Protected];
                Unprotect[Power];
                (z$_)^(-1) := Module[{x,y,l},
                   x = Vectorize[z$,Basis];
                   y = Table[C[l] -> x[[l]],{l,1,Length[Basis]}];
                   PolynomialMod[PowerMod[Determ /. y,-1,M] BigInverse /. y,M]
                   ] /; Not[NumberQ[z$]] && Vectorize[z$,Basis] =!= NotInSpan;
                Print["The inverse of ", Sum[ C[i] Basis[[i]],{i,1,L}],
                   " is given by ",BigInverse / Determ]]
]]]]]

ConwayPolynomial[p_Integer, n_Integer,X_Symbol] := Module[{Z,i,L1,L2},
   If[PrimeQ[p]==False, 
       Print[p, " is not prime."];
       Return[False]];
   If[n<1 || p<1, 
       Print["First two arguments must be positive."];
       Return[False]];
   If[n==1,
       Z = Cyclotomic[p-1,X];
       (* find the smallest number that satisfies the polynomial mod p. *)
       i = 1;
       While[Mod[(Z /. X->i),p] != 0, i++];
       Return[X+p-i],
   (* if n > 1, we use recursion to find the primitive polynomials 
      that satisfy the compatibility condition.  We start with all
      primitives *)
      Z = Cyclotomic[p^n-1,X];
      (* for all numbers d<n that divide n, we have a compatibility *)
      For[i=1,i<n,i++,
         If[Mod[n,i]==0,
            Z = PolynomialGCD[Z,
               (ConwayPolynomial[p,i,X] /. X->X^((p^n-1)/(p^i-1))),
                   Modulus->p]]];
      Z = Factor[Z,Modulus->p];
      (* One can prove that these factors will all have degree n *)
      Z[[0]]=List;
      (* The last step is to pick the "smallest" polynomial via Conway's 
         criterion.  But this is complicated. We delete the larger 
         of the first two in the list. *)
      While[Length[Z]>1,
         L1 = CoefficientList[Z[[1]],X];
         L2 = CoefficientList[Z[[2]],X];
         i=n+1;
         While[L1[[i]] == L2[[i]],i--];
         (* i will now be one more than largest power of x which 
            differ in the two polynomials *)
         If[(OddQ[n-i] && L1[[i]]>L2[[i]]) || 
            (EvenQ[n-i] && Mod[L1[[i]]-1,p]<Mod[L2[[i]]-1,p]),
               Z=Drop[Z,{1}],Z=Drop[Z,{2}]]];
   Return[Z[[1]]]]]


Unprotect[Norm];
ClearAll[Norm];

Norm[Poly_, a_Symbol] := Module[{Pol,i,j,k,n,T,gg,Temp},
   Pol = FixedPoint[Expand,Poly];
   n = 1;
   While[Exponent[a^n,a] === n, n++];
   If[((Variables[a^n] === {a}) || (Variables[a^n] === {}))
            && (Coefficient[Poly /. i_Rational -> j,j]===0),
      QuickNorm[Poly,a],
      T = {};
      Temp = Sum[ gg[i] a^i,{i,0,n-1}];
      For[i=0,i<n,i++,
         AppendTo[T,Table[Coefficient[Temp . (a^i),a,j],{j,0,n-1}]]];
      Temp = Expand[Det[T]];
      For[i=0, i<n, i++,
         Temp = Temp /. gg[i] -> Coefficient[Pol,a,i] ];
      FixedPoint[Expand, Temp]
   ]
]

Norm[Poly_, {a__Symbol}] := Module[{i,Temp},
   Temp = Poly;
   For[i = Length[{a}], i > 0, i--,
      Temp = Norm[Temp, {a}[[i]] ]];
   Temp]

QuickNorm[Poly_,a_Symbol] := Module[{Y,Z,i,n},
   If[Head[ZerosList$[a]] =!= List,
      n = 1;
      While[Exponent[a^n,a] === n, n++];
      Z = NSolve[Y^n == (a^n /. a -> Y), Y, 100];
      If[Length[Z] === n,
          ZerosList$[a] = Table[Z[[i]][[1]][[2]],{i,1,n}],
          Print["The extension variable is not defined properly."]];
   ];
   Z = Expand[Product[Poly /. a -> ZerosList$[a][[i]],
                            {i,1,Length[ZerosList$[a]]}]];
   Z = Z /. i_Complex -> Round[i];
   Z = Z /. i_Real -> Round[i]
]

UnNorm[Poly_, nn_Symbol, X_Symbol, a_Symbol] := Module[
  {Big,B,i,j,k,q,Z,d1,n,m,d,Y,Prod,Temp,T},
  B = {};
  Big = {};
  n = 1;
  While[Exponent[a^n,a] === n, n++];
  If[ Poly[[0]] === Times, Prod = Poly, Prod = {Poly}];
  Prod[[0]] = List;
  m = 1;
  For[k=1,k<=Length[Prod],k++,
     m = Max[m, Exponent[Prod[[k]],X] / n]];
  T = 1;
  If[ m > 1, T = Norm[X-a,a]];
  For[k=1,k<=m,k++,
     B = {};
     For[ i = 0, i< n, i++,
        Temp = Norm[(X - nn a)^k + a^i, a];
        AppendTo[B,Table[Coefficient[Coefficient[
                     Temp,nn,k*n-k-j],X,j],{j,0,n-1}]]];
    AppendTo[Big,B];
 ];
  For[k=1,k<=Length[Prod],k++,
    m = Exponent[Prod[[k]],X]/n;
    Prod[[k]] = Prod[[k]]/Coefficient[Prod[[k]],X,m*n];
    Temp = X^m;
    For[i=1,i <= m,i++,
      Z = Coefficient[Prod[[k]] /. X -> X nn,nn,n*m-i];
      If[ i > 1,
          Z = Z -
          Coefficient[Norm[Temp /. X ->(nn X - nn a),a],nn,n*m-i]];
      Z = PolynomialQuotient[Z,T^(m-i),X];
      d1 = Table[Coefficient[Z,X,j],{j,0,n-1}];
      d = Transpose[RowReduce[Transpose[Append[Big[[i]],d1]]]][[n+1]];
      Temp = Temp + Sum[d[[j]] a^(j-1)*X^(m-i),{j,1,n}];
    ];
    Prod[[k]] = Temp];
  Prod[[0]] = Times;
Prod]

UnNorm[Poly_, nn_Symbol, X_Symbol, w_, {a__Symbol}] := Module[
  {Big,B,i,j,k,q,Z,d1,n,m,d,L,Y,Prod,Temp,T,Bas},
  B = {};
  Big = {};
  L = {a};
  Bas = {1};
  For[i=1,i <= Length[L],i++,
     n = 1;
     While[Exponent[L[[i]]^n,L[[i]]] === n, n++];
     Bas = Flatten[Table[ L[[i]]^k Bas[[j]], {k,0,n-1},{j,1, Length[Bas]}]];
   ];
  n = Length[Bas];
  If[ Poly[[0]] === Times, Prod = Poly, Prod = {Poly}];
  Prod[[0]] = List;
  m = 1;
  For[k=1,k<=Length[Prod],k++,
     m = Max[m, Exponent[Prod[[k]],X] / n]];
  T = 1;
  If[ m > 1, T = Norm[X-w,L]];
  For[k=1,k<=m,k++,
     B = {};
     For[ i = 1, i<= n, i++,
        Temp = Norm[(X - nn w)^k + Bas[[i]], L];
        AppendTo[B,Table[Coefficient[Coefficient[
                     Temp,nn,k*n-k-j],X,j],{j,0,n-1}]]];
    AppendTo[Big,B];
 ];
  For[k=1,k<=Length[Prod],k++,
    m = Exponent[Prod[[k]],X]/n;
    Prod[[k]] = Prod[[k]]/Coefficient[Prod[[k]],X,m*n];
    Temp = X^m;
    For[i=1,i <= m,i++,
      Z = Coefficient[Prod[[k]] /. X -> X nn,nn,n*m-i];
      If[ i > 1,
          Z = Z -
          Coefficient[Norm[Temp /. X ->(nn X - nn w),L],nn,n*m-i]];
      Z = PolynomialQuotient[Z,T^(m-i),X];
      d1 = Table[Coefficient[Z,X,j],{j,0,n-1}];
      d = Transpose[RowReduce[Transpose[Append[Big[[i]],d1]]]][[n+1]];
      Temp = Temp + Sum[d[[j]] Bas[[j]]*X^(m-i),{j,1,n}];
    ];
    Prod[[k]] = Temp];
  Prod[[0]] = Times;
Prod]

SimpleExtension[a__Symbol] := Module[{L,i,j,k,n,w,p,Bas,d,pp,M},
   L = {a};
   Bas = {1};
   w = Sum[L[[i]],{i,1,Length[L]}];
   p = 1;
   d = 1;
   For[i=1,i <= Length[L],i++,
      n = 1;
      While[Exponent[L[[i]]^n,L[[i]]] === n, n++];
      Bas = Flatten[Table[ L[[i]]^k Bas[[j]], {k,0,n-1},{j,1, Length[Bas]}]];
   ];
   n = Length[Bas];
   While[
     M= {Vectorize[1,Bas]};
     pp = 1;
     For[i = 1, i<= n - 1, i++,
        pp =FixedPoint[Expand,w pp];
        AppendTo[M,Vectorize[pp,Bas]]];
     RowReduce[M][[n]][[n]] == 0,
     w = w + d L[[-p]];
     p++;
     If[d < Length[L], d++];
     If[p > Length[L], p = 1];
   ];
w]

FactorLister[Poly_] := Module[{Temp, L, i, j, k },
   Temp = FactorList[Poly];
   If[Temp === {}, Temp = {{1,1}}];
   If[NumberQ[Temp[[1]][[1]]] && (Length[Temp] > 1),
      L = {Expand[Temp[[1]][[1]] Temp[[2]][[1]]]}; k = 2,
      L = {Temp[[1]][[1]]}; k = 1
   ];
   For[i=1, i < Temp[[k]][[2]],i++,
      L = {L, Temp[[k]][[1]]}];
   For[i=k+1, i <= Length[Temp], i++,
      For[j=0, j < Temp[[i]][[2]], j++,
         L = {L, Temp[[i]][[1]]}]];
   Flatten[L]
]


QuickFactor[Poly_, X_Symbol, {a__Symbol}] :=
   Module[{Temp, L, b, i},
   L = {a};
   b = Last[L];
   L = Drop[L, -1];
   Temp = Poly /. X -> X - (2^Length[L] + 1) b;
   Temp = Norm[Temp, b];
   If[Length[L] > 0,
      QuickFactor[Temp, X, L],
      (Length[FactorLister[Temp]] > 1)]
]

TotalFactor[Poly_, X_Symbol, {a__Symbol}] :=
   Module[{nn, Temp, L, b, i, Prod},
   Prod = FactorLister[Poly];
   For[i=1,i<=Length[Prod], i++,
      If[(Length[CoefficientList[Prod[[i]],X]] > 2) &&
                             QuickFactor[Prod[[i]],X,{a}],
        If[Length[{a}] > 1, w = SimpleExtension[a],w = a];
        Temp = Prod[[i]];
        For[j =Length[{a}], j > 0, j--,
           Temp = Temp /. X -> X - nn Coefficient[w,{a}[[j]],1] {a}[[j]];
           Temp = Norm[Temp, {a}[[j]]]];
        Temp = Factor[Temp];
        If[Temp[[0]] === Times,
           Prod[[i]] = UnNorm[Temp, nn, X, w, {a}]];
       ]
   ];
   Prod[[0]] = Times;
   Prod
]

Coset::usage =
   "Coset[G_List, H_List] gives a list of all of the
    cosets of the subring H of G.";

Coset[G_List, H_List] := Module[{g, i},
    Unprotect[Plus];
    ClearAttributes[Plus,Listable];
    Clear[Plus];
    g_List + h_List := Module[{i,j},
    Union[Flatten[Table[g[[i]] + h[[j]],{i, Length[g]},
                    {j, Length[h] }], 1]]];
    g_List + x_ := Module[{i}, Union[Table[g[[i]] + x,
                          {i, Length[g] }]] ];
    x_ + g_List := Module[{i}, Union[Table[x + g[[i]],
                          {i, Length[g] }]] ];
    Protect[Plus];
    g = {H};
    Do[ If[MemberQ[Flatten[g,1], G[[i]] ],Null,g =
           Append[g, G[[i]] + H] ], {i,Length[G]}];
    Sort[g] ]

LftCoset::usage =
   "LftCoset[G_List, H_List] gives a list of all of the
    left cosets of the subgroup H of G.";

LftCoset[G_List, H_List] := Module[{g, i},
    g = {H};
    Do[ If[MemberQ[Flatten[g,1], G[[i]] ],Null,g =
           Append[g, DDot[G[[i]], H]] ], {i,Length[G]}];
    Sort[g] ]

RtCoset::usage =
   "RtCoset[G_List, H_List] gives a list of all of the
    right cosets of the subgroup H of G.";

RtCoset[G_List, H_List] := Module[{g, i},
    g = {H};
    Do[ If[MemberQ[Flatten[g,1], G[[i]] ],Null,g =
           Append[g,DDot[H, G[[i]]] ] ], {i,Length[G]}];
    Sort[g] ]

NormalClosure::usage =
   "NormalClosure[G_List, S_List] gives the smallest normal
    subgroup of G which contains the elements of the subset S.";

NormalClosure[G_List, H_List] := Module[{g,m,n,i,j,Repeat},
   g = Union[Flatten[
     Table[DDot[DDot[G[[i]], H[[j]]], (G[[i]]^(-1))],
        {i,Length[G]},{j,Length[H]}],1]];
   m = Length[g];
   Repeat = True;
   While[Repeat,
      Repeat = False;
      n = Length[g];
      Do[ Do[ If[ MemberQ[g,DDot[g[[i]],g[[j]]] ],Null,
                  Repeat = True;
                  g = Append[g,DDot[g[[i]],g[[j]]] ]
                ], {j,1,m}];
          If[2*Length[g] > Length[G],
             g = G;
             Repeat = False;
             Break[ ]
          ], {i,1,n} ] ];
   Sort[g] ]

Ideal::usage =
   "Ideal[R_List, X_List] gives the smallest ideal
    R which contains the elements of X.";

Ideal[R_List, H_List] := Module[{g,m,n,i,j,Repeat},
   Unprotect[Plus];
   ClearAttributes[Plus,Listable];
   Clear[Plus];
   g_List + h_List := Module[{i,j},
   Union[Flatten[Table[g[[i]] + h[[j]],{i, Length[g]},
                   {j, Length[h] }], 1]]];
   g_List + x_ := Module[{i}, Union[Table[g[[i]] + x,
                         {i, Length[g] }]] ];
   x_ + g_List := Module[{i}, Union[Table[x + g[[i]],
                         {i, Length[g] }]] ];
   Protect[Plus];
   g = Union[H, DDot[R,H], DDot[H,R], DDot[DDot[R,H],R]];
   m = Length[g];
   Repeat = True;
   If[2*Length[g] > Length[R],
     g = R;
     Repeat = False];
   While[Repeat,
      Repeat = False;
      n = Length[g];
      Do[ Do[ If[ MemberQ[g,g[[i]]+g[[j]] ],Null,
                  Repeat = True;
                  g = Append[g,g[[i]]+g[[j]] ]
                ], {j,1,m}];
          If[2*Length[g] > Length[R],
             g = R;
             Repeat = False;
             Break[ ]
          ], {i,1,n} ] ];
   Sort[g] ]

ConjugacyClasses::usage =
   "ConjugacyClasses[G_List] gives the list of the conjugacy
    classes for the group G.";

ConjugacyClasses[G_List] := Module[{i, j, g},
    g = {};
    Do[ If[MemberQ[Flatten[g,1],G[[i]] ],Null, g =
          Append[g,Union[Table[
          DDot[DDot[G[[j]], G[[i]]], (G[[j]]^(-1))],{j,Length[G]}]]]
         ], {i,Length[G]}];
   g ]

MutualCommutator::usage =
   "MutualCommutator[G_List, H_List] gives the mutual
    commutator subgroup [G, H], where G and H are subgroups
    of some larger group M. If either G or H equal M, the
    command Commutator is faster.";

MutualCommutator[G_List, H_List] := Module[{g, i, j},
   g = Union[Flatten[
     Table[DDot[DDot[DDot[G[[i]]^(-1), H[[j]]^(-1)], G[[i]]], H[[j]]],
           {i,Length[G]},{j,Length[H]}],1]];
   Group[g] ]

Commutator::usage =
   "Commutator[G_List, X_List] gives the commutator subgroup
    [G, H], where H is the subgroup generated by the elements
    of X.  If X generates G, this gives the derived group
    G'.";

Commutator[G_List, H_List] := Module[{g, m, n, i, j, Repeat},
   g = Union[Flatten[
     Table[DDot[DDot[DDot[G[[i]]^(-1), H[[j]]^(-1)], G[[i]]], H[[j]]] ,
           {i,Length[G]},{j,Length[H]}],1]];
   m = Length[g];
   Repeat = True;
   While[Repeat,
         Repeat = False;
         n = Length[g];
         Do[ Do[ If[ MemberQ[g,DDot[g[[i]], g[[j]]] ],Null,
                     Repeat = True;
                     g = Append[g,DDot[g[[i]], g[[j]]] ]
                   ], {j,1,m}];
             If[2*Length[g] > Length[G],
                g = G;
                Repeat = False;
                Break[ ]
             ], {i,1,n} ] ];
   Sort[g] ]

Normalizer::usage =
   "Normalizer[G_List, {a}] gives the normalizer of a in the
    group G.  If H is a subgroup of G, then
    Normalizer[G_List, H_List] gives the largest subgroup of
    G in which H is normal.";

Normalizer[G_List,H_List] := Module[{g, i, j, Include},
   g = {};
   Do[ Include = True;
      Do[ If[MemberQ[H, DDot[DDot[G[[i]], H[[j]]], G[[i]]^(-1)]], Null,
             Include = False;
             Break[ ]
            ], {j,Length[H] }];
      If[Include, g = Append[g, G[[i]] ] ], {i, Length[G] }];
   Sort[g] ]

GroupCenter::usage =
   "GroupCenter[G_List] gives the center of the group G,
    which is a normal subgroup.";

GroupCenter[G_List] := Module[{g,i,j,Include},
   g = {};
   Do[ Include = True;
      Do[ If[DDot[G[[i]], G[[j]]] === DDot[G[[j]], G[[i]]] ,Null,
             Include = False;
             Break[ ]
            ], {j, Length[G] }];
      If[Include, g = Append[g, G[[i]] ] ], {i, Length[G] }];
   Sort[g] ]

DefSumMod[n_Integer] := Module[{},
  InitGroup[0];
  DDot[x$_Integer, y$_Integer] := Mod[x$ + y$,n];
  IInv[x$_Integer] := Mod[-x$,n] ]

DefMultMod[n_Integer] := Module[{},
  InitGroup[1];
  DDot[x$_Integer, y$_Integer] := Mod[x$ * y$,n];
  IInv[x$_Integer] := If[GCD[x$,n] === 1,
                              PowerMod[x$,-1,n], Infinity] ]

DefMod[a_Integer] := Module[{i},
   $Char = Abs[a];
   If[a == 0,$Post =. , $Post = ModDefOut];
   ResetDot;
   Unprotect[Power];
   Unprotect[Plus];
   SetAttributes[Plus,Listable];
   Clear[Plus];
   Protect[Plus];
   ClearAll[Power];
   For[i=1,i<=Length[UsedSymbols],i++,
      ClearAll[Evaluate[UsedSymbols[[i]]]]];
   UsedSymbols = {};
   IInv[x$_Integer] := If[GCD[x$,a] === 1,
                              PowerMod[x$,-1,a], Infinity];
   DDot[x$_,y$_] := Modout[FixedPoint[Expand,x$ y$]];
   Ident$ = 0;
   LastInit$ = Domain$;
]

Unprotect[Cos];

Cos[x_ Pi] := Cos[-x Pi] /; x < 0;

Cos[x_ Pi] := Cos[(x - 2) Pi] /; x > 2;

Cos[x_ Pi] := Cos[(2 - x) Pi] /; x > 1;

Cos[x_ Pi] := -Cos[(1-x) Pi] /; x > 1/2;

Cos[Times[Rational[n_ ,m_],Pi]] := - Sum[(-1)^(n+i$) Cos[ i$ Pi/m], {i$,1,n-1}] - (-1)^n/2 /; m === (2 n + 1);

Cos/: Cos[n_ Pi]^2 := 1/2 + Cos[2 n Pi]/2;

Cos/: Cos[n_ Pi]*Cos[m_ Pi] := Cos[(n+m) Pi]/2 + Cos[(n-m) Pi]/2;

Protect[Cos];

Unfactorial[m_,n_] := Module[{Temp, index},
    index = 0;
    Temp = 1;
    While[(Temp < m)||(Temp < n), Temp *=(++index)];
    index
]

Unfactorial[n_] := Module[{Temp, index},
    index = 0;
    Temp = 1;
    While[Temp < n, Temp *=(++index)];
    index
]

NthPerm[n_Integer, u_Integer] := Module[{S, k, Temp, digit},
   Temp = Table[u-i+1,{i,1,u}];
   S = P[];
   For[k=u, k>0, k--,
      digit = Quotient[Mod[n-1,k!],(k-1)!]+1;
      S = Prepend[S,Temp[[digit]] ];
      Temp = Delete[Temp, digit];
   ];
   S
]

NthPerm[n_Integer] := Module[{u},
   u = Unfactorial[n];
   NthPerm[n,u]
]


PermToInt[x_] := Module[{total,u,i,j},
   u = Length[x];
   total = 1;
   For[i=2,i<=u,i++,
     For[j=1,j<i,j++,
        If[x[[j]] > x[[i]], total += (i-1)!]
     ]
   ];
   total
]

Unprotect[P];

P::usage = "P[i, j, k, ...] denotes the permutation that sends 1 to i,
            2 to j, 3 to k, etc.";

P/: DDot[P[x___Integer], P[y___Integer]] :=
   Module[{ u, L, M, Temp, i},
      (* version where (f o g)(x) = g(f(x))
      L = P[y]; 
      M = P[x]; *)
      (* version where (f o g)(x) = f(g(x))  *)
      L = P[x]; 
      M = P[y];       
      u = Max[Length[L], Length[M]];
      For[ i = Length[L] + 1, i <= u, i++, AppendTo[L,i] ];
      For[ i = Length[M] + 1, i <= u, i++, AppendTo[M,i] ];
      Temp = L;
      For[ i = 1, i <= u, i++, Temp[[i]] = L[[M[[i]] ]] ];
      While[ Temp[[u]] == u, Temp = Delete[Temp,u]; u--];
      Temp
   ]
   
P/: P[x___Integer]^(-1) := Module[{ u, L, Temp, i },
   L = P[x];
   u = Length[L];
   Temp = L;
   For[ i = 1, i <= u, i++, Temp[[L[[i]] ]] = i];
   Temp
]

P/: P[x___Integer]^n_Integer := P[x] . (P[x]^(n-1)) /; n > 1;

P/: P[x___Integer]^n_Integer := (P[x]^(-1)) . (P[x]^(n+1)) /; n < -1;

PermMult::usage = "PermMult[x, y] takes the product of the x-th and y-th
                   permutations, and converts this back to an integer.";

PermMult[x_Integer, y_Integer] := Module[{ u, L, M, i},
   u = Unfactorial[x,y];
   (* version where (f o g)(x) = g(f(x))
   L = NthPerm[y,u]; 
   M = NthPerm[x,u];  *)
   (* version where (f o g)(x) = f(g(x))  *)     
   L = NthPerm[x,u]; 
   M = NthPerm[y,u];
   PermToInt[Table[L[[M[[i]]]],{i,1,u}] ]
]

InvPerm[x_Integer] := Module[{ u, L, M, i},
   u = Unfactorial[x];
   L = NthPerm[x,u];
   M = L;
   For[i=1,i<=u,i++, M[[L[[i]] ]] = i];
   PermToInt[M] ]

InitPermMultiplication := Module[{x, y},
   InitGroup[1];
   DDot[x_Integer, y_Integer] := PermMult[x,y];
   x_Integer ^(-1) := InvPerm[x] ]

Unprotect[OrderedQ];
Unprotect[Sort];
Unprotect[C];
ResetDot;


OrderedQ[{P[a___Integer],P[b___Integer]}] := Module[{i},
   If[Length[P[a]] > Length[P[b]], Return[False] ];
   If[Length[P[a]] < Length[P[b]], Return[True] ];
   For[i=Length[P[a]], i>0, i--,
      If[P[a][[i]] < P[b][[i]], Return[False] ];
      If[P[a][[i]] > P[b][[i]], Return[True] ] ];
   Return[True] ]

Sort[a_] := Sort[a, OrderedQ[{#1, #2}]&]

C::usage = "C[i, j, k, ...] denotes the cycle (ijk...).";

ClearAll[C];

C/: DDot[C[], z_]:= z

C/: DDot[z_, C[]] := z

C/: NumberQ[C[x$_]] := True

C[a__] := C[] /; Signature[{a}] == 0

C[a__] := (RotateRight[{a}] /. List -> C) /; Sort[{a}][[1]] =!= {a}[[1]]

C/: DDot[C[a__], C[b__]] := DDot[{b} /. List -> C, {a} /. List -> C] /;
   ( OrderedQ[{Sort[{b}][[1]], Sort[{a}][[1]] }]
                                 && Signature[{a,b}] =!= 0)

C/: DDot[DDot[z$_, C[a__]], C[b__]] :=
              DDot[DDot[z$, {b} /. List -> C], {a} /. List -> C] /;
   ( OrderedQ[{Sort[{b}][[1]], Sort[{a}][[1]] }]
                                 && Signature[{a,b}] =!= 0)

C/: C[a___]^(-1) := Reverse[C[a]] /; Length[{a}] =!= 1

DDot/: (DDot[C[a___], b_])^(-1) := DDot[b^(-1), (C[a])^(-1)];

PermToCycle[P[a___Integer]] := Module[{i, j, k, T, R, L},
   R = C[];
   T = P[a];
   For[i = 1, i < Length[T], i++,
      If[T[[i]] > 0,
         L = {i};
         j = T[[i]];
         T[[i]] = 0;
         While[T[[j]] > 0,
            AppendTo[L,j];
            k = j;
            j = T[[k]];
            T[[k]] = 0];
         If[Length[L] > 1, R = R . (L /. List -> C)] ] ];
   R ]

DotOut[R_List] := Module[{T,S,i,j},
   S = R;
   For[i = 1, i <= Length[S], i++,
      If[ S[[i]][[0]] === DDot,
         T = S[[i]];
         S = Delete[S,i];
         For[j = Length[T],j > 0,j--,
            S = Insert[S,T[[j]],i] ];
         i-- ] ];
   S ]

C/: DDot[a__,C[b__]] := Module[{S, T, R, L, i, j, k},
   S = DotOut[{a,C[b]} /. P[x$__] -> PermToCycle[P[x$]] ];
   T = Union[Flatten[ S /. C -> List]];
   R = C[];
   For[i = 1, i < Length[T], i++,
      If[T[[i]] =!= Null,
         L = {};
         j = T[[i]];
         While[ MemberQ[T,j],
            AppendTo[L,j];
            T[[Position[T,j,1][[1]][[1]] ]] = Null;
            (* version where (f o g)(x) = g(f(x))
            For[ k = 1, k <= Length[S], k++, *)
            (* version where (f o g)(x) = f(g(x))  *)
            For[ k = Length[S], k >= 1, k--,
               If[ MemberQ[S[[k]],j],
   j = S[[k]][[Mod[Position[S[[k]],j,1][[1]][[1]],Length[S[[k]]]]+1]]
                 ]
               ]
            ];
         If[Length[L] > 1, R = DDot[R, L /. List -> C] ] ] ];
   R ] /;
     (Signature[Flatten[DotOut[{a,C[b]}],1,C] ] === 0) &&
     (Length[{b}] > 1)
     
C[a___][b_] := If[MemberQ[{a},b],
     {a}[[Mod[Position[{a},b,1][[1]][[1]],Length[{a}]]+1]],
     b ]

P[a___Integer][b_] := If[ b>0 && b <= Length[{a}],
    P[a][[b]],b,b]

P/: DDot[C[a___], P[b___]] := DDot[C[a], PermToCycle[P[b]]]

P/: DDot[DDot[z$_,C[a___]],P[b___]] := DDot[DDot[z$, C[a]], PermToCycle[P[b]]]

C/: DDot[P[a___], C[b___]] := DDot[PermToCycle[P[a]], C[b]]

C/: DDot[DDot[z$_,P[a___]],C[b___]] := DDot[DDot[z$, PermToCycle[P[a]]], C[b]]

CycleToPerm[C[]] := P[]

CycleToPerm[C[a__Integer]] := Module[{L,R,i },
   L = {a};
   R = Table[i,{i,Max[L]}];
   For[i=1,i<Length[L],i++,
     R[[L[[i]]]] = L[[i+1]] ];
   R[[L[[-1]]]] = L[[1]];
   Return[R /. List -> P ] ] /; Min[a] > 0

CycleToPerm[DDot[C[a___Integer], b_]] :=
               DDot[CycleToPerm[C[a]], CycleToPerm[b]]
CycleToPerm[DDot[a_, C[b___Integer]]] :=
               DDot[CycleToPerm[a], CycleToPerm[C[b]]]
ClearAttributes[Factor, Protected]
Unprotect[Factor];
ClearAttributes[Factor, Listable];
Factor[Poly_, F_List] := FFactor[Poly, F]
Factor[Polynom_,a__Symbol] := FFactor[Polynom, a]

LongDivision[dividend_List, divisor_List] := Module[{i,j,Dend,Quot,q, NN, MM, Isfactor},
(* divisor will not have a 1 at the end *)
Dend = dividend;
Quot = {};
NN =Length[Dend];
MM = Length[divisor] + 1;
For[i = NN - MM, i>=0, i--,
  q = Dend[[i + MM]];
  PrependTo[Quot, q];
  For[j = 1, j<= MM-1, j++,
    Dend[[i+j]] = Dend[[i+j]] - q*divisor[[j]];
     If[$Char =!= 0, Dend[[i+j]] = PolynomialMod[Dend[[i+j]],$Char]]];
  Dend = Drop[Dend,-1]];
Isfactor = True;
For[i = 1,i<=Length[Dend],i++,
If[Dend[[i]] =!= 0, Isfactor = False]];
Return[{Quot, Dend,Isfactor}]]

FFactor[Poly_,F_List] := Module[
      {Indepent,Degree,H,i,j,k,Prod,L,Term,Cont,Temp,WorkingTerm, WorkingList, jList, tempout},
   Indepent = Complement[Variables[Poly] , Variables[F]];
   If[Length[Indepent] =!= 1,Print["Polynomial must be in one variable."],
      If [Poly[[0]] =!= Times, Prod = {Poly},
               Prod = Poly;
               Prod[[0]] = List];
      Indepent = Indepent[[1]];
      L = Length[F];
      For[i=1,i<=Length[Prod],i++,
        If[Prod[[i]][[0]] === Power,
           Temp = Prod[[i]][[2]];
           WorkingTerm = Prod[[i]][[1]],
           Temp = 1;
           WorkingTerm = Prod[[i]]];
           Degree = Exponent[WorkingTerm,Indepent]; WorkingList = CoefficientList[WorkingTerm, Indepent];
        (*If[Degree > 1,
          For[k=1,k<=L,k++,
        If[PolynomialMod[Simplify[WorkingTerm /. Indepent -> F[[k]]], $Char] === 0,
                Prod = Insert[Prod,
  Modout[Expand[PolynomialQuotient[WorkingTerm,Indepent-F[[k]],Indepent]]]^Temp,
                                   i + 1];
                Prod[[i]] = (Indepent-F[[k]])^Temp;
                Degree = 1;
                k = L ]]];*)
        If[ Degree > 1,
          For[H = 1, 2 H <= Degree, H++,
             For[k=1,k<=H+1,k++,j[k] = 1];
jList = Table[F[[j[k]]],{k,H}];
             Cont = True;
             While[Cont,
                Term = Indepent^H + Sum[ F[[j[k]]] Indepent^(k-1),{k,H}];
tempout  = LongDivision[WorkingList, jList];
                If[ tempout[[3]],
Quot = Sum[tempout[[1]][[k]] Indepent^(k-1),{k,Length[tempout[[1]]]}];
                   Prod = Insert[Prod,Quot^Temp,i+1];
                   Prod[[i]] = Term^Temp;
                   Degree = H;
                   Cont = False];
                k = 1;
                j[k]++;
                While[j[k] > L, j[k] = 1;k++;j[k]++];
jList = Table[F[[j[k]]],{k,H}];
                If[k > H,Cont = False]]]]];
      Prod[[0]] = Times;
      Prod]]

AnOrSn[Polynom_,Quad_,L_,H_] := Module[{X,i,j,k,R,T,d,dd,n,d0,d1,Bas,M,Temp},
   X = Variables[Polynom][[1]];
   R = NSolve[Polynom==0,X,20];
   R = Table[R[[i]][[1]][[2]],{i,Length[R]}];
   k = Product[R[[i]]-R[[j]],{i,1,Length[R]-1},{j,i+1,Length[R]}];
   k = Sqrt[Round[k^2]];
   If[IntegerQ[k],
     T = Table[X - H[[i]],{i,1,Length[H]}];
     dd = Expand[X^2 - Quad/Coefficient[Quad,X,2]] /. X -> d;
     Define[d^2,dd];
     AppendTo[T,d];
     AppendTo[T,X - (PolynomialQuotient[Quad,X-d,X]/ Coefficient[Quad,X,2])];
     R = Product[T[[i]]-T[[j]],{i,1,Length[T]-1},{j,i+1,Length[T]}] - k;
     R = FixedPoint[Expand,R];
     d1 = Coefficient[R,d,1];
     d0 = Coefficient[R,d,0];
     Bas = {1};
     For[i=1,i <= Length[L],i++,
        n = 1;
        While[Exponent[L[[i]]^n,L[[i]]] === n, n++];
        Bas = Flatten[Table[ L[[i]]^k Bas[[j]], {k,0,n-1},{j,1, Length[Bas]}]];
      ];
     n = Length[Bas];
     M = {Table[If[IntegerQ[Bas[[i]]], j = Select[d1, IntegerQ],
          j = Coefficient[d1,Bas[[i]]];
          If[IntegerQ[j],Null,
              If[j[[0]]=== Plus,j = Select[j,IntegerQ],j=0]]];
          j,{i,1,n}]};
     For[k=2, k<=n,k++,
         R = d1 . Bas[[k]];
         AppendTo[M, Table[If[IntegerQ[Bas[[i]]], j = Select[R, IntegerQ],
          j = Coefficient[R,Bas[[i]]];
          If[IntegerQ[j],Null,
              If[j[[0]]=== Plus,j = Select[j,IntegerQ],j=0]]];
          j,{i,1,n}]]];
     AppendTo[M, Table[If[IntegerQ[Bas[[i]]], j = Select[-d0, IntegerQ],
          j = Coefficient[-d0,Bas[[i]]];
          If[IntegerQ[j],Null,
              If[j[[0]]=== Plus,j = Select[j,IntegerQ],j=0]]];
          j,{i,1,n}]];
     M = Transpose[RowReduce[Transpose[M]]][[n+1]];
     Temp = X - Sum[M[[i]] Bas[[i]],{i,1,n}];
     Temp = Temp*PolynomialQuotient[Quad,Temp,X],
     Temp = Quad];
   Temp]

FFactor[Polynom_,a__Symbol] := Module[{X, Temp, i,j,k,n,L,T,U,Poly},
   X = Variables[Polynom];
   L = {a};
   T = L;
   For[i=1,i<=Length[L],i++,
     n = 1;
     While[Exponent[L[[i]]^n,L[[i]]] === n, n++];
     T = Union[L, Variables[L[[i]]^n]]
   ];
   X = Complement[X, T];
   If[Length[X] > 1,
      Print["Only one variable in the polynomial can be indeterminate."],
      X = X[[1]];
      Poly = FactorList[Polynom];
      k = Length[Poly];
      T = 1;
      For[j=1,j<=k,j++,
         Temp = Poly[[j]][[1]];
         For[i=1,i<= Length[L],i++,
            If[FixedPoint[Expand, Temp /. X -> L[[i]] ] === 0,
               T = T*(X - L[[i]])^Poly[[j]][[2]];
               Temp = PolynomialQuotient[Temp, X - L[[i]], X];
               U = X - PolynomialQuotient[
                       X^2 - L[[i]]^2 /. L[[i]] -> X,X-L[[i]],X];
               If[FixedPoint[Expand, Temp /. X -> U ] === 0,
                 T = T*(X - U)^Poly[[j]][[2]];
                 Temp = PolynomialQuotient[Temp, X - U, X] ];
               i--] ];
         If[(T[[0]] === Times) &&
            (Length[T] + 2 === Exponent[Polynom,X]) &&
            (Length[Variables[Polynom]] === 1) &&
            (Exponent[Temp,X] === 2),
             Temp2 = AnOrSn[Polynom,Expand[Temp],L,T];
             If[(Temp2 === Temp)&&(Length[L] + 2 < Exponent[Polynom,X]),
                Temp2 = TotalFactor[Temp, X, L]];
             T = T*Temp2,
         T = T*TotalFactor[Temp, X, L]^Poly[[j]][[2]]];
      ];
      T
   ]
]

PolarPlot1 := Show[Graphics[{Line[{{0,0},{3,4}}], 
               Circle[{0,0},1,{0,0.92729}], 
               Text["\[Theta]",{0.7,0.4}], 
               Text["r",{1.5,2.5}],
               Text["(x,y) = x + y i",{3.2,4},{-1,0}]}], 
               Axes -> True, AspectRatio -> 1, 
               PlotRange -> All]

DrawGalois[i_] := Module[{G},
   If[i == 1,
         G = Graphics[{Text["\[DoubleStruckCapitalQ]",{.5,1}],Text["\[DoubleStruckCapitalQ](\!\(\*RadicalBox[\(2\), \(3\)]\))",{0,.5},{-1,0}],Text["\[DoubleStruckCapitalQ](\!\(\*SubscriptBox[\(\[Omega]\), \(3\)]\)\!\(\*RadicalBox[\(2\), \(3\)]\))",{0.35,.5}],Text["\[DoubleStruckCapitalQ](\!\(\*SubsuperscriptBox[\(\[Omega]\), \(3\), \(2\)]\)\!\(\*RadicalBox[\(2\), \(3\)]\))",{0.65,.5}],
           Text["\[DoubleStruckCapitalQ](\!\(\*SqrtBox[\(-3\)]\))",{1,.5},{1,0}],Text["\[DoubleStruckCapitalQ](\!\(\*RadicalBox[\(2\), \(3\)]\),\!\(\*SubscriptBox[\(\[Omega]\), \(3\)]\)\!\(\*RadicalBox[\(2\), \(3\)]\))",{0.5,0}],
Line[{{.47,.95},{0.05,.55}}],
Line[{{.49,.95},{0.35,.55}}],
Line[{{.51,.95},{0.65,.55}}],
RGBColor[0,1,0],
Line[{{.53,.95},{0.95,.55}}],
 Line[{{.47,.05},{0.05,.45}}],
Line[{{.49,.05},{0.35,.45}}],
Line[{{.51,.05},{0.65,.45}}],
Line[{{.53,.05},{0.95,.45}}],
Line[{{.50,.05},{0.50,.95}}],
RGBColor[0,0,1],
Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.77,.77}],
Text["\!\(\*SubscriptBox[\(S\), \(3\)]\)",{.53,.77}],
Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.23,.23}],
 Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.40,.23}],
Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.60,.23}],
Text["\!\(\*SubscriptBox[\(Z\), \(3\)]\)",{.77, .23}]}]];
     If[i == 2,
         G = Graphics[{Text["\!\(\*SubscriptBox[\(S\), \(3\)]\)",{.5,1}],Text["{(),(1 2)}",{0,.5},{-1,0}],Text["{(), (1 3)}",{0.35,.5}],Text["{(), (2 3)}",{0.65,.5}],
Text["\!\(\*SubscriptBox[\(A\), \(3\)]\)",{1,.5},{1,0}],Text["{()}",{0.5,0}],
Line[{{.47,.95},{0.05,.55}}],
Line[{{.49,.95},{0.35,.55}}],
Line[{{.51,.95},{0.65,.55}}],
RGBColor[0,1,0],
Line[{{.53,.95},{0.95,.55}}],
 Line[{{.47,.05},{0.05,.45}}],
Line[{{.49,.05},{0.35,.45}}],
Line[{{.51,.05},{0.65,.45}}],
Line[{{.53,.05},{0.95,.45}}],
Line[{{.50,.05},{0.50,.95}}],
RGBColor[0,0,1],
Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.77,.77}],
Text["\!\(\*SubscriptBox[\(S\), \(3\)]\)",{.53,.77}],
Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.23,.23}],
 Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.40,.23}],
Text["\!\(\*SubscriptBox[\(Z\), \(2\)]\)",{.60,.23}],
Text["\!\(\*SubscriptBox[\(Z\), \(3\)]\)",{.77, .23}]}]];
Show[G]]

Protect[OrderedQ, Sort, C, P, Dot, Factor];

Print["Initialization Done"];
