(* ::Package:: *)

$FilledCircle = "\(CenterDot)";
If[$VersionNumber >= 3.0,
   $FilledCircle = "\[FilledSmallCircle]";
   $DefaultFont = {"Courier-New", 12};
   SetAttributes[CenterDot, Flat]
];

If[$VersionNumber < 6.0,
   NextPrime[n_Integer] := Module[{k = n},
        While[!PrimeQ[k], k++];
        Return[k]
   ]
]

If[$VersionNumber < 6.0,
   RRaster[T_] := RasterArray[T];
   OnlyAmbientLight := False,
   RRaster[T_] := Raster[(T /. RGBColor -> List)];
   OnlyAmbientLight :=  {{"Ambient", White}}
]

(* For some reason ChineseRemainder conflicts with the code.  We redefine it here. *)

CRT[a_, b_, x_, y_] := Module[{t, u, v},
  t = ExtendedGCD[x, y];
  If[t[[1]] == 1,
   u = t[[2]][[1]];
   v = t[[2]][[2]];
   Return [Mod[a*v*y + b*u*x, x*y]],
   Print["Moduli not coprime"]]]
   
(* Intersection no longer works with a "set of sets".  We define a new code here. *)

SetIntersection[L_List] := Module[{LL},
  LL = L;
  If[Length[LL] > 1,
   If [LL[[1]][[0]] == List,
    LL[[0]] = Intersection]];
  LL]  

(*  Set up DDot to be the new dot product.  *)

ResetDot := Module[{},
   ClearAttribute[Dot,Protected];
   Unprotect[Dot];
   Dot := DDot;
   ClearAll[DDot];
   DDot[x_] := x; (* OneIdentity *)
   DDot[x_ ,DDot[y_ , z_]] := DDot[DDot[x , y] , z];
   DDot[x__, y_, z_] := DDot[DDot[x , y] , z];
   DDot/: (DDot[C[a___], b_])^(-1) := (b^(-1)) . ((C[a])^(-1));
   DDot[x__,y_][z_] := DDot[x][y[z]];  (* Used to evaluate a product of cycles at a number *)
   Format[DDot[x_, y_]] := StringForm["`` \[CenterDot] ``", x, y];
   Protect[Dot];
]

InitGroup::usage =
  "InitGroup[e] initializes the group, using e as the
   identity element.  This clears any previously defined
   groups.  The dot is used to separate letters in the
   words.";

InitGroup[a_] := Module[{x, y, z, n},
  ResetDot;
  Unprotect[Power];
  ClearAttributes[Power, Protected];
  ClearAll[Power];
  DDot[z_, a] := z;
  DDot[a, z_] := z;
  DDot[z_, z_^(-1)] := a;
  DDot[z_^(-1), z_] := a;
  a ^(-1) := a;
  DDot[DDot[x_ , y_], y_^(-1)] := x;
  DDot[DDot[x_ , y_^(-1)], y_] := x;
  DDot[x_ , y_]^(-1) := DDot[y^(-1), x^(-1)];
  x_^n_Integer :=
    x . (x^(n-1)) /; (n > 1) && (Head[x] =!= List);
  x_^n_Integer :=
    (x^(-1)) . (x^(n+1)) /; (n < -1) && (Head[x] =!= List);
  DDot[g_List, h_List] := Module[{i,j},
          Union[Flatten[Table[g[[i]] . h[[j]],
                        {i,Length[g]},{j,Length[h]}],1]]];
  DDot[g_List, x_] := Module[{i}, Union[Table[DDot[g[[i]], x],
                          {i, Length[g] }]] ];
  DDot[x_, g_List] := Module[{i}, Union[Table[DDot[x, g[[i]]],
                          {i, Length[g] }]] ];
  g_List^(-1) := Module[{i}, Union[Table[g[[i]]^(-1),
                          {i, Length[g] }]]];
  g_List^(n_Integer) := Module[{i}, Table[g[[i]]^n,
                        {i, Length[g] }]];
  Unprotect[OrderedQ];
  ClearAll[OrderedQ];
  OrderedQ[{P[x___Integer],P[y___Integer]}] := Module[{i},
   If[Length[P[x]] > Length[P[y]], Return[False] ];
   If[Length[P[x]] < Length[P[y]], Return[True] ];
   For[i=Length[P[x]], i>0, i--,
      If[P[x][[i]] < P[y][[i]], Return[False] ];
      If[P[x][[i]] > P[y][[i]], Return[True] ] ];
   Return[True] ];
  OrderedQ[{a,_}] := True;
  OrderedQ[{_,a}] := False;
  Protect[OrderedQ];
  Ident$ = a ]

Define::usage =
   "Define[u, v], where u and v are words, defines the
    inference rule u -> v.  Define[F[u],v] defines the
    value of the homomorphism F at u to be v.";

Define[a_,a_] := Print["Rule already defined."]

Define[DDot[a_, b_] , c_] := Module[{},
   DDot[a, b] := c;
   DDot[DDot[z$_ , a] , b] := z$ . c ] /; UnsameQ[DDot[a, b],c]

Define[F_[a_],b_] := Module[{x,y},
   F[a] := b ;
   x = DDot[a^(-1), a];
   y = DDot[b^(-1), b];
   If[ UnsameQ[F[x], y], F[x] := y ]
] /; UnsameQ[ F[a] , b ]

Define[a_^(-1) , b_] := Module[{},
   Unprotect[Power];
   ClearAttributes[Power,Protected];
   a^(-1) := b;]

Homomorph::usage =
   "Homomorph[F] defines F to be a homomorphism between two
    groups M and K."

Homomorph[F$_Symbol] := Module[{},
   ClearAll[F$];
   F$[DDot[a$_, b$_]] := DDot[F$[a$], F$[b$]];
   F$[a$_^(-1)] := F$[a$]^(-1);
   F$[{{a$_}}] := { F$[a$] };
   F$[{{a$__,b$_}}] := Union[F$[{{a$}}],{F$[b$]}] ];

SetAttributes[Homomorph, HoldAll];

Kernel::usage =
   "Kernel[F,G] finds the kernel of the homomorphism F whose
    domain is G.";

Kernel[F_,G_] := Module[{g,k,i,e},
   g = Union[G];
   k = {};
   e = DDot[g[[1]]^(-1), g[[1]]];
   Do[ If[ F[g[[i]] ] === F[e],
          k = Append[k,g[[i]] ] ], {i,1,Length[g]}];
   Return[k] ]

HomoInverse::usage =
   "HomoInverse[F,S,G] takes the inverse homomorphism F,
    whose domain is G, of the element or set of elements S.";

HomoInverse[F_,S_,G_] := Module[{g,k,i},
   g = Union[G];
   k = {};
   Do[ If[Intersection[
                 Flatten[{S}],Flatten[{F[g[[i]]]}]] != {},
          k = Append[k,g[[i]] ] ], {i,1,Length[g]}];
   Return[k] ]

CheckGroup[G_List] := Module[{i,j,k,n,m,L,T,U,Test},
  g = Union[G];
  L = Length[g];
  Test = True;
  For[i=1,i<=L,i++,
    T = Union[Table[DDot[g[[i]], g[[j]]],{j,1,L}]];
    U = Union[Table[DDot[g[[j]], g[[i]]],{j,1,L}]];
    If[(T =!= g) || (U =!= g), Test = False]
  ];
  If[Test === False,
    Print["The Latin square property does not hold for this set."],
    For[i=1,i<=L,i++,
       For[j=1,j<=L,j++,
          For[k=1,k<=L,k++,
             m = DDot[g[[i]], g[[j]]];
             n = DDot[g[[j]], g[[k]]];
             If[DDot[m, g[[k]]] =!= DDot[g[[i]], n],
                  Print[g[[i]], " \[CenterDot] (", g[[j]]," \[CenterDot] ", g[[k]],
                        ") is not equal to (",g[[i]]," \[CenterDot] ",g[[j]],
                        ") \[CenterDot] ",g[[k]]];
                  Test = False]]]];
    If[Test,
       Print["This set of elements is a group."],
       Print["Associtive Property does not hold."]]]];

CheckHomo::usage = "CheckHomo[F,D] verifies that F is a
   homomorphism with a domain of D.";

CheckHomo[f_,D_List] := Module[{i,j},
   For[i=Length[D], i>0, i--,
      For[j=Length[D], j>0, j--,
         If[ DDot[f[D[[i]]], f[D[[j]]]] =!= f[DDot[D[[i]],D[[j]]] ],
            Print["f[",D[[i]],"] \[CenterDot] f[",D[[j]],
               "] is not equal to f[", D[[i]] \[CenterDot] D[[j]],"]"];
            Return[False] ] ] ];
   Return[True] ]

ClearDefs::usage =
  "ClearDefs resets the dot product, erasing all group definitions.";

(* TODO: determine exactly what ClearDefs should do. *)

ClearDefs := Module[{},
   ResetDot;
   Unprotect[Power];
   Unprotect[OrderedQ];
   ClearAll[Power];
   ClearAll[OrderedQ];
   g_List^(n_Integer) := Module[{i}, Table[g[[i]]^n,
                         {i,Length[g] }]];
   OrderedQ[{P[a___Integer],P[b___Integer]}] := Module[{i},
   If[Length[P[a]] > Length[P[b]], Return[False] ];
   If[Length[P[a]] < Length[P[b]], Return[True] ];
   For[i=Length[P[a]], i>0, i--,
      If[P[a][[i]] < P[b][[i]], Return[False] ];
      If[P[a][[i]] > P[b][[i]], Return[True] ] ];
   Return[True] ];
   Protect[Power, OrderedQ]; ]

Group::usage =
   "Group[X_List] gives a list of elements of the group
    symbolically presented by the set of generators X and
    the inference rules previously defined.";

Group[G_List] := Module[{m, n, i, j, g, Repeat},
   g = Union[G];
   m = Length[g];
   Repeat = True;
   While[Repeat,
      Repeat = False;
      n = Length[g];
      Do[ Do[ If[ MemberQ[g, DDot[g[[i]], g[[j]]] ],Null,
                  Repeat = True;
                  g = Append[g, DDot[g[[i]], g[[j]]] ]
                ], {i,1,n} ], {j,1,m} ] ];
   Sort[g] ]

Group[a_Symbol] := Group[{a}]

ToStr[x_] := StringJoin[Select[Characters[ToString[
             If[MemberQ[ToCharacterCode[ToString[x]],10],InputForm[x],x]
             ]],# =!= " " &]]

ColorTable := {RGBColor[0,0,0],
               RGBColor[1,1,0],RGBColor[1,0,1],RGBColor[0,1,1],
               RGBColor[1,0,0],RGBColor[0,1,0],RGBColor[.6,.4,.8],
               RGBColor[1,.6,0],RGBColor[.7,.8,.7],RGBColor[.8,.6,.5],
               RGBColor[.5,.6,.8],RGBColor[.8,.2,.5],RGBColor[.8,.6,.2],
               RGBColor[.6,.6,.2],RGBColor[1,.4,.4],RGBColor[.2,.8,.7],
               RGBColor[1,.6,1],RGBColor[.7,1,0],RGBColor[0,0,1],
               RGBColor[.6,.4,.4],RGBColor[0,.6,1],RGBColor[1,.8,.7],
               RGBColor[.4,.2,1],RGBColor[1,.8,.4],RGBColor[.2,.6,.4],
               RGBColor[.5,.8,.8],RGBColor[.4,.8,.5],RGBColor[0,1,.6],
               RGBColor[.8,.5,.2],RGBColor[.2,.2,.9]};

CayleyTable::usage =
   "CayleyTable[X_List] gives a Cayley table of the
    elements in the list, using different colors for
    different elements.  The list can have no more than 27
    elements.";

CayleyTable[Q_List] := Module[{i,j,T},
   If[Length[Q] > 27, Print["Group too big to print table."],
     T = Table[
      If[i===0,
     If[j===0,RGBColor[1,1,1],ColorTable[[j+1]]],
      If[j===0,ColorTable[[i+1]],
       If[MemberQ[Q,DDot[Q[[i]],Q[[j]]]],
         ColorTable[[Position[Q,DDot[Q[[i]],Q[[j]]],1][[1]][[1]]+1]],
         RGBColor[0,0,0]]]],{i,Length[Q],0,-1},
                                           {j,0,Length[Q]}];
       If[Max[Table[Length[Characters[ToStr[Q[[i]]]]],
          {i,1,Length[Q]}]]*(Length[Q]+1) < 85,
      Show[Graphics[RRaster[T]],
          Graphics[Table[
         Text[StyleForm[ToStr[Q[[i]]],FontSize->18],{i+.5,Length[Q]+.5}],
                                          {i,1,Length[Q]}]],
         Graphics[Table[
         Text[StyleForm[ToStr[Q[[j]]],FontSize->18],{.5,Length[Q] - j + .5}],
                                          {j,1,Length[Q]}]],
         Graphics[Table[
         Text[If[MemberQ[Q,DDot[Q[[i]],Q[[j]]]],
                                   StyleForm[ToStr[DDot[Q[[i]],Q[[j]]]],FontSize->18]," "],
           {j + .5, Length[Q] - i + .5}],
            {i,1,Length[Q]},{j,1,Length[Q]}]],
         Graphics[Line[{{1,0},{1,Length[Q]},
                                 {Length[Q]+1,Length[Q]}}]]],
    Show[Graphics[RRaster[T]],
         Graphics[Table[
    Text[StyleForm[ToStr[Q[[i]]],FontSize->18],{-.5,Length[Q] - i + .5},{1,0}],
                                           {i,1,Length[Q]}]],
         Graphics[Line[{{1,0},{1,Length[Q]},
                                  {Length[Q]+1,Length[Q]}}]],
         AspectRatio -> Automatic,
         PlotRange -> All]]]]

RootCount::usage =
   "RootCount[G_List, k_Integer] gives the number of solutions to x^k = e in G";
    
RootCount[G_List, k_Integer] := Module[{i,j,t, count},
         count = 0;
         For[i=1, i<= Length[G], i++,
             t = G[[i]];
             For[j = 1, j <= k, j++,
                 t = t . G[[i]]
             ];
             If[t == G[[i]], count++]
         ];
         count]
         
ElementOrder::usage = 
	"ElementOrder[a_element] gives the order of the element a";

ElementOrder[L_List]:= Module[{LL,i},
    LL={};
    For[i=1,i<=Length[L],i++,
        AppendTo[LL,ElementOrder[L[[i]]]];
    ];
    LL]

ElementOrder[x_]:= Module[{y,n},
    y=x . x;
    n=1;
    While[x=!=y,
       n=n+1;
       y=y . x
    ];
    n]	
			          
LftCoset::usage =
   "LftCoset[G_List, H_List] gives a list of all of the
    left cosets of the subgroup H of G.";

LftCoset[G_List, H_List] := Module[{g, i},
    g = {H};
    Do[ If[MemberQ[Flatten[g,1], G[[i]] ],Null,g =
           Append[g, DDot[G[[i]], H]] ], {i,Length[G]}];
    Sort[g] ]

RtCoset::usage =
   "RtCoset[G_List, H_List] gives a list of all of the
    right cosets of the subgroup H of G.";

RtCoset[G_List, H_List] := Module[{g, i},
    g = {H};
    Do[ If[MemberQ[Flatten[g,1], G[[i]] ],Null,g =
           Append[g,DDot[H, G[[i]]] ] ], {i,Length[G]}];
    Sort[g] ]

NormalClosure::usage =
   "NormalClosure[G_List, S_List] gives the smallest normal
    subgroup of G which contains the elements of the set S.";

NormalClosure[G_List, H_List] := Module[{g,m,n,i,j,Repeat},
   g = Union[Flatten[
     Table[DDot[DDot[G[[i]], H[[j]]], G[[i]]^(-1)],
        {i,Length[G]},{j,Length[H]}],1]];
   m = Length[g];
   Repeat = True;
   While[Repeat,
      Repeat = False;
      n = Length[g];
      Do[ Do[ If[ MemberQ[g,DDot[g[[i]], g[[j]]] ],Null,
                  Repeat = True;
                  g = Append[g,DDot[g[[i]], g[[j]]] ]
                ], {j,1,m}];
          If[2*Length[g] > Length[G],
             g = G;
             Repeat = False;
             Break[ ]
          ], {i,1,n} ] ];
   Sort[g] ]

ConjugacyClasses::usage =
   "ConjugacyClasses[G_List] gives the list of the conjugacy
    classes for the group G.";

ConjugacyClasses[G_List] := Module[{i, j, g},
    g = {};
    Do[ If[MemberQ[Flatten[g,1],G[[i]] ],Null, g =
          Append[g,Union[Table[
          DDot[DDot[G[[j]], G[[i]]], G[[j]]^(-1)],{j,Length[G]}]]]
         ], {i,Length[G]}];
   g ]

MutualCommutator::usage =
   "MutualCommutator[G_List, H_List] gives the mutual
    commutator subgroup [G, H], where G and H are subgroups
    of some larger group M. If either G or H equal M, the
    command Commutator is faster.";

MutualCommutator[G_List, H_List] := Module[{g, i, j},
   g = Union[Flatten[
     Table[DDot[DDot[DDot[G[[i]]^(-1), H[[j]]^(-1)], G[[i]]], H[[j]]],
           {i,Length[G]},{j,Length[H]}],1]];
   Group[g] ]

Commutator::usage =
   "Commutator[G_List, X_List] gives the commutator subgroup
    [G, H], where H is the subgroup generated by the elements
    of X.  If X generates G, this gives the derived group
    G'.";

Commutator[G_List, H_List] := Module[{g, m, n, i, j, Repeat},
   g = Union[Flatten[
     Table[DDot[DDot[DDot[G[[i]]^(-1), H[[j]]^(-1)], G[[i]]], H[[j]]] ,
           {i,Length[G]},{j,Length[H]}],1]];
   m = Length[g];
   Repeat = True;
   While[Repeat,
         Repeat = False;
         n = Length[g];
         Do[ Do[ If[ MemberQ[g,DDot[g[[i]], g[[j]]] ],Null,
                     Repeat = True;
                     g = Append[g,DDot[g[[i]], g[[j]]] ]
                   ], {j,1,m}];
             If[2*Length[g] > Length[G],
                g = G;
                Repeat = False;
                Break[ ]
             ], {i,1,n} ] ];
   Sort[g] ]

Normalizer::usage =
   "Normalizer[G_List, {a}] gives the normalizer of a in the
    group G.  If H is a subgroup of G, then
    Normalizer[G_List, H_List] gives the largest subgroup of
    G in which H is normal.";

Normalizer[G_List,H_List] := Module[{g, i, j, Include},
   g = {};
   Do[ Include = True;
      Do[ If[MemberQ[H, DDot[DDot[G[[i]], H[[j]]], G[[i]]^(-1)]], Null,
             Include = False;
             Break[ ]
            ], {j,Length[H] }];
      If[Include, g = Append[g, G[[i]] ] ], {i, Length[G] }];
   Sort[g] ]

GroupCenter::usage =
   "GroupCenter[G_List] gives the center of the group G,
    which is a normal subgroup.";

GroupCenter[G_List] := Module[{g,i,j,Include},
   g = {};
   Do[ Include = True;
      Do[ If[DDot[G[[i]], G[[j]]] === DDot[G[[j]], G[[i]]] ,Null,
             Include = False;
             Break[ ]
            ], {j, Length[G] }];
      If[Include, g = Append[g, G[[i]] ] ], {i, Length[G] }];
   Sort[g] ]

DefSumMod[n_Integer] := Module[{},
  InitGroup[0];
  DDot[x$_Integer, y$_Integer] := Mod[x$ + y$,n];
  IInv[x$_Integer] := Mod[-x$, n] ]

DefMultMod[n_Integer] := Module[{},
  InitGroup[1];
  DDot[x$_Integer, y$_Integer] := Mod[x$ * y$,n];
  IInv[x$_Integer] := If[GCD[x$,n] === 1,
                              PowerMod[x$,-1,n], Infinity] ]

AsciiToCent[x_] := Which[
   x < 33, 0,
   x < 34, 47,
   x < 48, x+47,
   x < 65, x-18,
   x < 94, x-64,
   x < 127, x-46,
   True, 0]

CentToAscii[x_] := Which[
   x < 1, 32,
   x < 30, x+64,
   x < 47, x+18,
   x < 48, 33,
   x < 81, x+46,
   x < 95, x-47,
   x == 95, 196,
   x == 96, 203,
   x == 97, 214,
   x == 98, 220,
   x == 99, 223,
   True, 32]

MessageToNumber[s_String] := Module[{total,strlist,i},
   strlist = ToCharacterCode[s];
   total = 0;
   For[i = 1, i <= Length[strlist], i++,
      total = total * 100 + AsciiToCent[ strlist[[i]] ]
   ];
   Return[total]
]

NumberToMessage[n_Integer] := Module[{Temp = n,strlist,m},
   strlist = "";
   While[Temp > 0,
      m = Mod[Temp,100];
      Temp = Quotient[Temp,100];
      strlist = FromCharacterCode[CentToAscii[m]] <> strlist;
   ];
   If[StringLength[strlist] == 0,
         strlist = FromCharacterCode[0] ];
   Return[strlist]
]

TerryColor =
  {RGBColor[1,0,0],RGBColor[0,1,0],RGBColor[0,1,1]};

ShowTerry := Module[{},Print[
   Show[Graphics[{
  {TerryColor[[1]],Polygon[{{0,0},{0,2},{1.732,-1}}]},
  {TerryColor[[2]],Polygon[{{0,0},{0,2},{-1.732,-1}}]},
  {TerryColor[[3]],Polygon[{{0,0},{1.732,-1},{-1.732,-1}}]}},
  AspectRatio -> Automatic, PlotRange -> {{-2,2},{-2,2}}]]];]

Terry[x_] := Module[{i},
  TerryList = {Graphics[{{TerryColor[[1]], 
       Polygon[{{0, 0}, {0, 2}, {Sqrt[3], -1}}]}, {TerryColor[[2]], 
       Polygon[{{0, 0}, {0, 2}, {-Sqrt[3], -1}}]}, {TerryColor[[3]], 
       Polygon[{{0, 0}, {Sqrt[3], -1}, {-Sqrt[3], -1}}]}}, 
     AspectRatio -> Automatic, PlotRange -> {{-2, 2}, {-2, 2}}]};
  TerryRot[x];
  ListAnimate[TerryList, AnimationRepetitions -> 1]]
  
TerryRot[DDot[x_, y_]] := Module[{},
  TerryRot[x];
  TerryRot[y];]  
  
TerryRot[RotLft] := Module[{i, Temp},
  For[i = 1, i <= 10, i++,
   th = 2*Pi*i/3/10.0;
   AppendTo[TerryList, 
    Graphics[{{TerryColor[[1]], 
       Polygon[{{0, 0}, {-2*Sin[th], 2*Cos[th]}, {2*Sin[2*Pi/3 - th], 
          2*Cos[2*Pi/3 - th]}}]}, {TerryColor[[2]], 
       Polygon[{{0, 0}, {-2*Sin[th + 2*Pi/3], 
          2*Cos[th + 2*Pi/3]}, {-2*Sin[th], 2*Cos[th]}}]},
      {TerryColor[[3]], 
       Polygon[{{0, 0}, {2*Sin[2*Pi/3 - th], 
          2*Cos[2*Pi/3 - th]}, {-2*Sin[th + 2*Pi/3], 
          2*Cos[th + 2*Pi/3]}}]}}, PlotRange -> {{-2, 2}, {-2, 2}}]]];
  Temp = TerryColor[[1]];
       TerryColor[[1]] = TerryColor[[3]];
       TerryColor[[3]] = TerryColor[[2]];
       TerryColor[[2]] = Temp;]
       
TerryRot[RotRt] := Module[{i, Temp},
  For[i = 1, i <= 10, i++,
   th = 2*Pi*i/3/10.0;
   AppendTo[TerryList, 
    Graphics[{{TerryColor[[1]], 
       Polygon[{{0, 0}, {2*Sin[th], 2*Cos[th]}, {2*Sin[th + 2*Pi/3], 
          2*Cos[th + 2*Pi/3]}}]}, {TerryColor[[2]], 
       Polygon[{{0, 0}, {2*Sin[th - 2*Pi/3], 
          2*Cos[th - 2*Pi/3]}, {2*Sin[th], 2*Cos[th]}}]},
      {TerryColor[[3]], 
       Polygon[{{0, 0}, {2*Sin[th + 2*Pi/3], 
          2*Cos[th + 2*Pi/3]}, {2*Sin[th - 2*Pi/3], 
          2*Cos[th - 2*Pi/3]}}]}}, PlotRange -> {{-2, 2}, {-2, 2}}]]];
  Temp = TerryColor[[1]];
       TerryColor[[1]] = TerryColor[[2]];
       TerryColor[[2]] = TerryColor[[3]];
       TerryColor[[3]] = Temp;]
       
TerryRot[Spin] := Module[{i, Temp},
  For[i = 1, i <= 9, i++,
   th = Pi*i/9.0;
   AppendTo[TerryList, 
    Graphics[{{TerryColor[[1]], 
       Polygon[{{0, 0}, {0, 2}, {Sqrt[3]*Cos[th], 
          Sin[th]/2 - 1}}]}, {TerryColor[[2]], 
       Polygon[{{0, 0}, {-Sqrt[3]*Cos[th], -Sin[th]/2 - 1}, {0, 2}}]},
      {TerryColor[[3]], 
       Polygon[{{0, 0}, {Sqrt[3]*Cos[th], 
          Sin[th]/2 - 1}, {-Sqrt[3]*Cos[th], -Sin[th]/2 - 1}}]}}, 
     PlotRange -> {{-2, 2}, {-2, 2}}]]];
  Temp = TerryColor[[1]];
       TerryColor[[1]] = TerryColor[[2]];
       TerryColor[[2]] = Temp;]
       
TerryRot[FlipLft] := Module[{i, Temp},
  For[i = 1, i <= 9, i++,
   th = Pi*i/9.0;
   AppendTo[TerryList, Graphics[{
      {TerryColor[[1]], 
       Polygon[{{0, 
          0}, {-Sqrt[3]/2 + Sqrt[3]*Cos[th]/2 - Sqrt[3]*Sin[th]/4, 
          1/2 + 3*Cos[th]/2 + Sin[th]/4}, {Sqrt[
           3], -1}}]}, {TerryColor[[2]], 
       Polygon[{{0, 
          0}, {-Sqrt[3]/2 - Sqrt[3]*Cos[th]/2 + Sqrt[3]*Sin[th]/4, 
          1/2 - 3*Cos[th]/2 - Sin[th]/4}, {-Sqrt[3]/2 + 
           Sqrt[3]*Cos[th]/2 - Sqrt[3]*Sin[th]/4, 
          1/2 + 3*Cos[th]/2 + Sin[th]/4}}]}, {TerryColor[[3]], 
       Polygon[{{0, 
          0}, {Sqrt[3], -1}, {-Sqrt[3]/2 - Sqrt[3]*Cos[th]/2 + 
           Sqrt[3]*Sin[th]/4, 1/2 - 3*Cos[th]/2 - Sin[th]/4}}]}}, 
     PlotRange -> {{-2, 2}, {-2, 2}}]]];
  Temp = TerryColor[[1]];
       TerryColor[[1]] = TerryColor[[3]];
       TerryColor[[3]] = Temp;]
       
TerryRot[FlipRt] := Module[{i, Temp},
  For[i = 1, i <= 9, i++,
   th = Pi*i/9.0;
   AppendTo[TerryList, Graphics[{
      {TerryColor[[1]], 
       Polygon[{{0, 
          0}, {Sqrt[3]/2 - Sqrt[3]*Cos[th]/2 - Sqrt[3]*Sin[th]/4, 
          1/2 + 3*Cos[th]/2 - Sin[th]/4}, {Sqrt[3]/2 + 
           Sqrt[3]*Cos[th]/2 + Sqrt[3]*Sin[th]/4, 
          1/2 - 3*Cos[th]/2 + Sin[th]/4}}]}, {TerryColor[[2]], 
       Polygon[{{0, 
          0}, {-Sqrt[3], -1}, {Sqrt[3]/2 - Sqrt[3]*Cos[th]/2 - 
           Sqrt[3]*Sin[th]/4, 
          1/2 + 3*Cos[th]/2 - Sin[th]/4}}]}, {TerryColor[[3]], 
       Polygon[{{0, 
          0}, {Sqrt[3]/2 + Sqrt[3]*Cos[th]/2 + Sqrt[3]*Sin[th]/4, 
          1/2 - 3*Cos[th]/2 + Sin[th]/4}, {-Sqrt[3], -1}}]}}, 
     PlotRange -> {{-2, 2}, {-2, 2}}]]];
  Temp = TerryColor[[2]];
       TerryColor[[2]] = TerryColor[[3]];
       TerryColor[[3]] = Temp;]
       
TerryRot[Stay] := Module[{},
  For[i = 1, i <= 5, i++,
   AppendTo[TerryList, 
    Graphics[{{TerryColor[[1]], 
       Polygon[{{0, 0}, {0, 2}, {Sqrt[3], -1}}]}, {TerryColor[[2]], 
       Polygon[{{0, 0}, {0, 2}, {-Sqrt[3], -1}}]}, {TerryColor[[3]], 
       Polygon[{{0, 0}, {Sqrt[3], -1}, {-Sqrt[3], -1}}]}}, 
     AspectRatio -> Automatic, PlotRange -> {{-2, 2}, {-2, 2}}]]]]


InitTerry := Module[{},
   InitGroup[Stay];
   Define[DDot[RotLft,RotLft],RotRt];
   Define[DDot[RotLft,RotRt],Stay];
   Define[DDot[RotLft,Spin],FlipRt];
   Define[DDot[RotLft,FlipRt],FlipLft];
   Define[DDot[RotLft,FlipLft],Spin];
   Define[DDot[RotRt,RotLft],Stay];
   Define[DDot[RotRt,RotRt],RotLft];
   Define[DDot[RotRt,Spin],FlipLft];
   Define[DDot[RotRt,FlipRt],Spin];
   Define[DDot[RotRt,FlipLft],FlipRt];
   Define[DDot[Spin,RotLft],FlipLft];
   Define[DDot[Spin,RotRt],FlipRt];
   Define[DDot[Spin,Spin],Stay];
   Define[DDot[Spin,FlipLft],RotLft];
   Define[DDot[Spin,FlipRt],RotRt];
   Define[DDot[FlipRt,RotLft],Spin];
   Define[DDot[FlipRt,RotRt],FlipLft];
   Define[DDot[FlipRt,Spin],RotLft];
   Define[DDot[FlipRt,FlipRt],Stay];
   Define[DDot[FlipRt,FlipLft],RotRt];
   Define[DDot[FlipLft,RotLft],FlipRt];
   Define[DDot[FlipLft,RotRt],Spin];
   Define[DDot[FlipLft,Spin],RotRt];
   Define[DDot[FlipLft,FlipRt],RotLft];
   Define[DDot[FlipLft,FlipLft],Stay];
   Define[FlipRt^(-1),FlipRt];
   Define[FlipLft^(-1),FlipLft];
   Define[Spin^(-1),Spin];
   Define[RotLft^(-1),RotRt];
   Define[RotRt^(-1),RotLft];
   {Stay,FlipRt,RotRt,FlipLft,RotLft,Spin}]

ShowBooks := Module[{i},
   Print[Show[Graphics[Table[{{BookColor[[i+1]],Polygon[{
   {2i,-i},{2i+.16,-.34-i},{2i+.382,-.618-i},
   {2i+.66,-.84-i},{2i+1,-1-i},{2i+1.421,-1.079-i},
   {2i+2,-1-i},{2i+2,-.875-i},{2i+2.25,-.75-i},
   {2i+5.333,2.333-i},{2i+5.333,9.333-i},
   {2i+5.167,9.417-i},{2i+3.5,7.75-i},
   {2i+3.5,10.25-i},{2i+3.333,10.333-i},
   {2i+.25,7.25-i},{2i+.125,7-i},{2i,7-i}}]},
   RGBColor[1,1,1],Polygon[{{2i+4.5,8.75-i},
   {2i+2,6.25-i},{2i+2,6-i},{2i+1.421,5.921-i},
   {2i+1,6-i},{2i+.66,6.16-i},{2i+.382,6.382-i},
   {2i+.271,6.521-i},{2i+3.167,9.417-i}}],
   RGBColor[0,0,0],Line[{
   {2i,-i},{2i+.16,-.34-i},{2i+.382,-.618-i},
   {2i+.66,-.84-i},{2i+1,-1-i},{2i+1.421,-1.079-i},
   {2i+2,-1-i},{2i+2,6-i},{2i+1.421,5.921-i},
   {2i+1,6-i},{2i+.66,6.16-i},{2i+.382,6.382-i},
   {2i+.16,6.66-i},{2i,7-i},{2i,-i}}],
   Line[{{2i+3.167,9.417-i},{2i+4.5,8.75-i}}],
   Line[{{2i+2.25,6.25-i},{2i+2.25,-.75-i},
   {2i+5.333,2.333-i},{2i+5.333,9.333-i},
   {2i+2.25,6.25-i},{2i+2,6.125-i}}],
   Line[{{2i,7-i},{2i+.25,7-i},{2i+3.5,10.25-i}}],
   Line[{{2i+2,6-i},{2i+2,6.25-i},{2i+5.167,9.417-i},
   {2i+5.333,9.333-i}}],
   Line[{{2i+.25,6.547-i},{2i+.25,7-i}}],
   Line[{{2i+.125,7-i},{2i+.25,7.25-i},
   {2i+3.333,10.333-i},{2i+3.5,10.25-i},
   {2i+3.5,9.25-i}}]},
   {i,0,Length[BookColor]-1}]],
   AspectRatio -> Automatic]];];

InitBooks[n_] := Module[{i},
  BookColor = Table[ColorTable[[i+3]],{i,n}];
  ShowBooks;];

MoveBooks[Left] := Module[{},
  BookColor = RotateLeft[BookColor];
  ShowBooks;];

MoveBooks[Right] := Module[{},
  BookColor = RotateRight[BookColor];
  ShowBooks;];

MoveBooks[Rev] := Module[{},
  BookColor = Reverse[BookColor];
  ShowBooks;];

MoveBooks[Stay] := ShowBooks;

MoveBooks[First] := Module[{Temp},
  If[Length[BookColor] > 1,
    Temp = BookColor[[1]];
    BookColor[[1]] = BookColor[[2]];
    BookColor[[2]] = Temp];
  ShowBooks;];

MoveBooks[Last] := Module[{Temp},
  If[Length[BookColor] > 1,
    Temp = BookColor[[-1]];
    BookColor[[-1]] = BookColor[[-2]];
    BookColor[[-2]] = Temp];
  ShowBooks;];

MoveBooks[DDot[a_, b_]] := Module[{},
  MoveBooks[a];
  MoveBooks[b];];
  
AArrow[Color_,{{x1_,y1_},{x2_,y2_}}] := Module[{dx,dy,Len},
    dx = x2-x1;
    dy = y2-y1;
    Len = N[Sqrt[dx N[dx] + dy N[dy]]];
    If[Len + 0. =!= 0. ,
     {Color,Line[{{N[x1],N[y1]},{N[x2 - (.1 dx)/Len],N[y2 - (.1 dy)/Len]}}],
      Polygon[{{N[x2],N[y2]},
          {N[x2-(.1 dx + .05 dy)/Len],
              N[y2-(.1 dy - .05 dx)/Len]},
          {N[x2-(.1 dx - .05 dy)/Len],
              N[y2-(.1 dy + .05 dx)/Len]}}]},
     Len = N[Sqrt[2 x2 N[x2] + 2 y2 N[y2]]];
     dx = x2/Len;
     dy = y2/Len;
     {Color,Line[
 {{N[x2 - .1 dy - .1 dx],N[y2 + .1 dx - .1 dy]},
  {N[x2 - .1307 dy - .1459 dx],N[y2 + .1307 dx - .1459 dy]},
  {N[x2 - .2 dx - .1414 dy],N[y2 - .2 dy + .1414 dx]},
  {N[x2 - .1307 dy - .2541 dx],N[y2 + .1307 dx - .2541 dy]},
  {N[x2 - .1 dy - .3 dx],N[y2 + .1 dx - .3 dy]},
  {N[x2 - .0541 dy - .3307 dx],N[y2 + .0541 dx - .3307 dy]},
  {N[x2 - .3413 dx],N[y2 - .3414 dy]},
  {N[x2 + .0541 dy - .3307 dx],N[y2 - .0541 dx - .3307 dy]},
  {N[x2 + .1 dy - .3 dx],N[y2 - .1 dx - .3 dy]},
  {N[x2 + .1307 dy - .2541 dx],N[y2 - .1307 dx - .2541 dy]},
  {N[x2 - .2 dx + .1414 dy],N[y2 - .2 dy - .1414 dx]},
  {N[x2 + .1307 dy - .1459 dx],N[y2 - .1307 dx - .1459 dy]},
  {N[x2 + .1 dy - .1 dx],N[y2 - .1 dx - .1 dy]},
  {N[x2],N[y2]}}],
      Polygon[{{N[x2],N[y2]},
          {N[x2 -.15 dy -.05 dx],N[y2 + .15 dx -.05 dy]},
          {N[x2 -.05 dy -.15 dx],N[y2 + .05 dx -.15 dy]}}]}]
    ]

CircleGraph[G_,F__] := Module[{L,i},
   L = Length[G];
   Show[Graphics[{{ColorTable[[4]],Circle[{0,0},1]},
     Table[Text[StyleForm[$FilledCircle, FontSize -> 18],
        {Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},{.1,0}],{n,1,L}],
     Text[StyleForm[ToStr[G[[1]]],FontSize->18],{0,1.1},{0,-1}],
     If[EvenQ[L],Text[StyleForm[ToStr[G[[1 + Quotient[L,2]]]],FontSize->18],
                                         {0,-1.1},{0,1}],{}],
     Table[Text[StyleForm[ToStr[G[[n+1]]],FontSize->18],
         {Sin[2 Pi n/N[L]]*1.1,Cos[2 Pi n/N[L]]*1.1},{-1,0}],
                       {n,1,Quotient[L-1,2]}],
     Table[Text[StyleForm[ToStr[G[[n+1]]],FontSize->18],
          {Sin[2 Pi n/N[L]]*1.1,Cos[2 Pi n/N[L]]*1.1},{1,0}],
                       {n,Quotient[L+2,2],L-1}],
     Table[
       Table[i = Position[G,{F}[[j]][G[[n+1]]]];
           If[i === {},
              {Text[StyleForm["?",FontSize -> 18, FontWeight->"Bold"],{0,0}],
               AArrow[ColorTable[[4+j]],
               {{Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},
               {.1 Sin[2 Pi n/N[L]], .1 Cos[2 Pi n/N[L]]}}]},
                  i = i[[1]][[1]]-1;
                  AArrow[ColorTable[[4+j]],
                    {{Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},
           {Sin[2 Pi i/N[L]],Cos[2 Pi i/N[L]]}}]],{n,0,L-1}],
                                         {j,1,Length[{F}]}]},
 AspectRatio -> Automatic,PlotRange->All]]]/; Length[{F}] > 1

CircleGraph[G_,F_] := Module[{T,L,n,i,j,k,Q},
   L = Length[G];
   T = {};
   For[i=1,i<=L,i++,
      If[Position[T,i] === {},
         Q = {i};
         j = Position[G,F[G[[i]]]];
         If[j==={},j=i,j=j[[1]][[1]]];
         While[Position[Union[Q,T],j]==={},
           AppendTo[Q,j];
           j = Position[G,F[G[[j]]]];
           If[j==={},j=i,j=j[[1]][[1]]]];
         AppendTo[T,Q]]];
   TempData = {{ColorTable[[4]],Circle[{0,0},1]},
     Table[Text[StyleForm[$FilledCircle,FontSize -> 18],
        {Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},{.1,0}],{n,1,L}],
     Text[StyleForm[ToStr[G[[1]]],FontSize->18],{0,1.1},{0,-1}],
     If[EvenQ[L],Text[StyleForm[ToStr[G[[1 + Quotient[L,2]]]],FontSize->18],
                                         {0,-1.1},{0,1}],{}],
     Table[Text[StyleForm[ToStr[G[[n+1]]],FontSize->18],
         {Sin[2 Pi n/N[L]]*1.1,Cos[2 Pi n/N[L]]*1.1},{-1,0}],
                         {n,1,Quotient[L-1,2]}],
     Table[Text[StyleForm[ToStr[G[[n+1]]],FontSize->18],
          {Sin[2 Pi n/N[L]]*1.1,Cos[2 Pi n/N[L]]*1.1},{1,0}],
                         {n,Quotient[L+2,2],L-1}],
     Table[
       Table[n = T[[k]][[j]]-1;
             i = Position[G,F[G[[n+1]]]];
              If[i === {},
                 {Text[StyleForm["?",FontSize->18,FontWeight->"Bold"],{0,0}],
                  AArrow[ColorTable[[4+k]],
                   {{Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},
              {.1 Sin[2 Pi n/N[L]], .1 Cos[2 Pi n/N[L]]}}]},
                  i = i[[1]][[1]]-1;
             AArrow[ColorTable[[4+k]],
               {{Sin[2 Pi n/N[L]],Cos[2 Pi n/N[L]]},
                  {Sin[2 Pi i/N[L]],Cos[2 Pi i/N[L]]}}]],
                                   {j,1,Length[T[[k]]]}],
                                           {k,1,Length[T]}]};
     Show[Graphics[TempData,
     AspectRatio -> Automatic,PlotRange->All]]]

Add[x_] := DDot[#, x]&;

Mult[x_] := DDot[x, #]&;

SSort[x_] := If[Head[x] === List, Sort[x],x];

LeftMult[x_] := SSort[DDot[#, x]]&;

RightMult[x_] := SSort[DDot[x, #]]&;

Inv := IInv[#]&;

Pow[x_] := #^x&;

GraphHomo[F_,G_List] := Module[{g,L,d,i,M,p},
  L = Length[G];
  d = {};
  p = {};
  If[ L > 1,
     For[i=1, i<=L, i++,
        t = Position[d,F[G[[i]]],1];
        If[t === {},
           AppendTo[d,F[G[[i]]]];
           AppendTo[p,Length[d]],
           AppendTo[p,t[[1]][[1]]]
          ]
         ];
     M = Length[d];
     TempData = {
         {ColorTable[[4]],Line[{{0,0},{0,1}}]},
         {ColorTable[[4]],Line[{{1,0},{1,1}}]},
         Table[Text[StyleForm[$FilledCircle,FontSize->18],
            {0,i/N[L-1]}],{i,0,L-1}],
        Table[Text[StyleForm[ToStr[G[[i]]],FontSize->18],
            {-0.1,(L-i)/N[L-1]},{1,0}],
              {i,1,L}],
         If[M === 1,
            p = Table[2,{i,1,L}];
            M = 3;
            {Text[StyleForm[$FilledCircle,FontSize->18],{1,.5}],
             Text[StyleForm[ToStr[d[[1]]],FontSize->18],{1.1,0.5},{-1,0}]},
            {Table[Text[StyleForm[$FilledCircle,FontSize->18],
              {1,i/N[M-1]}],{i,0,M-1}],
            Table[Text[StyleForm[ToStr[d[[i]]],FontSize->18],
              {1.1,(M-i)/N[M-1]},{-1,0}],
              {i,1,M}]}],
         Table[AArrow[ColorTable[[4 + p[[i]]]],
              {{0,(L-i)/N[L-1]},{1,(M-p[[i]])/N[M-1]}}],
              {i,1,L}] };
     Show[Graphics[TempData,AspectRatio -> Automatic, PlotRange -> All]]
]]

Colorlist = {RGBColor[1,0,0],RGBColor[0,1,0],RGBColor[0,0,1],
             RGBColor[1,1,0],RGBColor[1,0,1],RGBColor[0,1,1],
             RGBColor[1,.6,0],RGBColor[0,0,0]};

ShowOctahedron := Module[{},
  Print[Show[Graphics3D[
  {{Colorlist[[1]],Polygon[{{0,0, 1},{0, 1,0},{ 1,0,0}}]},
   {Colorlist[[2]],Polygon[{{0,0, 1},{0, 1,0},{-1,0,0}}]},
   {Colorlist[[3]],Polygon[{{0,0, 1},{0,-1,0},{ 1,0,0}}]},
   {Colorlist[[4]],Polygon[{{0,0, 1},{0,-1,0},{-1,0,0}}]},
   {Colorlist[[5]],Polygon[{{0,0,-1},{0, 1,0},{ 1,0,0}}]},
   {Colorlist[[6]],Polygon[{{0,0,-1},{0, 1,0},{-1,0,0}}]},
   {Colorlist[[7]],Polygon[{{0,0,-1},{0,-1,0},{ 1,0,0}}]},
   {Colorlist[[8]],Polygon[{{0,0,-1},{0,-1,0},{-1,0,0}}]}},
    Lighting -> OnlyAmbientLight, ViewPoint -> {5,1.5,2}, Boxed -> False]]];
 ]

ShowOctahedronWithQuaternions :=
 Show[Graphics3D[{{Colorlist[[1]],
     Polygon[{{0, 0, 1}, {0, 1, 0}, {1, 0, 0}}]}, {Colorlist[[2]],
     Polygon[{{0, 0, 1}, {0, 1, 0}, {-1, 0, 0}}]}, {Colorlist[[3]],
     Polygon[{{0, 0, 1}, {0, -1, 0}, {1, 0, 0}}]}, {Colorlist[[4]],
     Polygon[{{0, 0, 1}, {0, -1, 0}, {-1, 0, 0}}]}, {Colorlist[[5]],
     Polygon[{{0, 0, -1}, {0, 1, 0}, {1, 0, 0}}]}, {Colorlist[[6]],
     Polygon[{{0, 0, -1}, {0, 1, 0}, {-1, 0, 0}}]}, {Colorlist[[7]],
     Polygon[{{0, 0, -1}, {0, -1, 0}, {1, 0, 0}}]}, {Colorlist[[8]],
     Polygon[{{0, 0, -1}, {0, -1, 0}, {-1, 0, 0}}]}},
   Lighting -> OnlyAmbientLight, ViewPoint -> {5, 1.5, 2},
   Boxed -> False],
  Graphics3D[Text[StyleForm["i\[CenterDot]j", FontSize -> 18], {0, 0, 1.1}]],
  Graphics3D[Text[StyleForm["i", FontSize -> 18], {0, 1.1, 0}]],
  Graphics3D[Text[StyleForm["i\.b3\[CenterDot]j", FontSize -> 18], {0, 0, -1.1}]],
  Graphics3D[Text[StyleForm["i\.b3", FontSize -> 18], {0, -1.1, 0}]],
  Graphics3D[Text[StyleForm["<\[Dash]\[Dash]\[Dash]\[Dash]\[Dash]\[Dash]i\.b2\[CenterDot]j", FontSize -> 18], {-1, 0, 0}, {-1, 0}]],
  Graphics3D[Text[StyleForm["j", FontSize -> 18], {.7, 0, 0}]]]

RotateOctahedron[a] := Module[{Temp},
   Temp = Colorlist[[1]];
   Colorlist[[1]] = Colorlist[[8]];
   Colorlist[[8]] = Temp;
   Temp = Colorlist[[4]];
   Colorlist[[4]] = Colorlist[[5]];
   Colorlist[[5]] = Temp;
   Temp = Colorlist[[2]];
   Colorlist[[2]] = Colorlist[[6]];
   Colorlist[[6]] = Temp;
   Temp = Colorlist[[3]];
   Colorlist[[3]] = Colorlist[[7]];
   Colorlist[[7]] = Temp;
   ShowOctahedron;
]
RotateOctahedron[b] := Module[{Temp},
   Temp = Colorlist[[2]];
   Colorlist[[2]] = Colorlist[[5]];
   Colorlist[[5]] = Colorlist[[3]];
   Colorlist[[3]] = Temp;
   Temp = Colorlist[[4]];
   Colorlist[[4]] = Colorlist[[6]];
   Colorlist[[6]] = Colorlist[[7]];
   Colorlist[[7]] = Temp;
   ShowOctahedron;
]
RotateOctahedron[c] := Module[{Temp},
   Temp = Colorlist[[1]];
   Colorlist[[1]] = Colorlist[[3]];
   Colorlist[[3]] = Colorlist[[7]];
   Colorlist[[7]] = Colorlist[[5]];
   Colorlist[[5]] = Temp;
   Temp = Colorlist[[2]];
   Colorlist[[2]] = Colorlist[[4]];
   Colorlist[[4]] = Colorlist[[8]];
   Colorlist[[8]] = Colorlist[[6]];
   Colorlist[[6]] = Temp;
   ShowOctahedron;
]


RotateOctahedron[DDot[x_, y_]] := Module[{},
   RotateOctahedron[x];
   RotateOctahedron[y];
]

PColor =
  {RGBColor[1,0,0],RGBColor[1,0,0],RGBColor[1,0,0],
   RGBColor[1,0,0],RGBColor[1,0,0],RGBColor[1,0,0],
   RGBColor[1,1,0],RGBColor[1,1,0],RGBColor[1,1,0],
   RGBColor[1,1,0],RGBColor[1,1,0],RGBColor[1,1,0],
   RGBColor[0,1,0],RGBColor[0,1,0],RGBColor[0,1,0],
   RGBColor[0,1,0],RGBColor[0,1,0],RGBColor[0,1,0],
   RGBColor[0,0,1],RGBColor[0,0,1],RGBColor[0,0,1],
   RGBColor[0,0,1],RGBColor[0,0,1],RGBColor[0,0,1]};

ShowPuzzle := Module[{},
   If[PColor[[1]]=!= 0,
   Print[Show[Graphics3D[
{{PColor[[ 1]],Polygon[{{-1, 1, 1},{ 1, 3, 1},{ 1, 1, 3}}]},
 {PColor[[ 2]],Polygon[{{-1, 1, 1},{ 1, 1, 3},{-1,-1, 3}}]},
 {PColor[[ 3]],Polygon[{{-1, 1, 1},{-1,-1, 3},{-3,-1, 1}}]},
 {PColor[[ 4]],Polygon[{{-1, 1, 1},{-3,-1, 1},{-3, 1,-1}}]},
 {PColor[[ 5]],Polygon[{{-1, 1, 1},{-3, 1,-1},{-1, 3,-1}}]},
 {PColor[[ 6]],Polygon[{{-1, 1, 1},{-1, 3,-1},{ 1, 3, 1}}]},
 {PColor[[ 7]],Polygon[{{ 1,-1, 1},{ 1, 1, 3},{ 3, 1, 1}}]},
 {PColor[[ 8]],Polygon[{{ 1,-1, 1},{ 3, 1, 1},{ 3,-1,-1}}]},
 {PColor[[ 9]],Polygon[{{ 1,-1, 1},{ 3,-1,-1},{ 1,-3,-1}}]},
 {PColor[[10]],Polygon[{{ 1,-1, 1},{ 1,-3,-1},{-1,-3, 1}}]},
 {PColor[[11]],Polygon[{{ 1,-1, 1},{-1,-3, 1},{-1,-1, 3}}]},
 {PColor[[12]],Polygon[{{ 1,-1, 1},{-1,-1, 3},{ 1, 1, 3}}]},
 {PColor[[13]],Polygon[{{ 1, 1,-1},{ 3, 1, 1},{ 1, 3, 1}}]},
 {PColor[[14]],Polygon[{{ 1, 1,-1},{ 1, 3, 1},{-1, 3,-1}}]},
 {PColor[[15]],Polygon[{{ 1, 1,-1},{-1, 3,-1},{-1, 1,-3}}]},
 {PColor[[16]],Polygon[{{ 1, 1,-1},{-1, 1,-3},{ 1,-1,-3}}]},
 {PColor[[17]],Polygon[{{ 1, 1,-1},{ 1,-1,-3},{ 3,-1,-1}}]},
 {PColor[[18]],Polygon[{{ 1, 1,-1},{ 3,-1,-1},{ 3, 1, 1}}]},
 {PColor[[19]],Polygon[{{-1,-1,-1},{-3, 1,-1},{-3,-1, 1}}]},
 {PColor[[20]],Polygon[{{-1,-1,-1},{-3,-1, 1},{-1,-3, 1}}]},
 {PColor[[21]],Polygon[{{-1,-1,-1},{-1,-3, 1},{ 1,-3,-1}}]},
 {PColor[[22]],Polygon[{{-1,-1,-1},{ 1,-3,-1},{ 1,-1,-3}}]},
 {PColor[[23]],Polygon[{{-1,-1,-1},{ 1,-1,-3},{-1, 1,-3}}]},
 {PColor[[24]],Polygon[{{-1,-1,-1},{-1, 1,-3},{-3, 1,-1}}]}},
  Lighting -> OnlyAmbientLight, ViewPoint -> {5,4,4.5}, Boxed -> False]]],
   Print[Show[Graphics3D[
{{PColor[[ 2]],Polygon[{{-1, 1, 1},{ 1, 1, 3},{-1,-1, 3}}]},
 {PColor[[ 4]],Polygon[{{-1, 1, 1},{-3,-1, 1},{-3, 1,-1}}]},
 {PColor[[ 6]],Polygon[{{-1, 1, 1},{-1, 3,-1},{ 1, 3, 1}}]},
 {PColor[[ 8]],Polygon[{{ 1,-1, 1},{ 3, 1, 1},{ 3,-1,-1}}]},
 {PColor[[10]],Polygon[{{ 1,-1, 1},{ 1,-3,-1},{-1,-3, 1}}]},
 {PColor[[12]],Polygon[{{ 1,-1, 1},{-1,-1, 3},{ 1, 1, 3}}]},
 {PColor[[14]],Polygon[{{ 1, 1,-1},{ 1, 3, 1},{-1, 3,-1}}]},
 {PColor[[16]],Polygon[{{ 1, 1,-1},{-1, 1,-3},{ 1,-1,-3}}]},
 {PColor[[18]],Polygon[{{ 1, 1,-1},{ 3,-1,-1},{ 3, 1, 1}}]},
 {PColor[[19]],Polygon[{{-1,-1,-1},{-3, 1,-1},{-3,-1, 1}}]},
 {PColor[[21]],Polygon[{{-1,-1,-1},{-1,-3, 1},{ 1,-3,-1}}]},
 {PColor[[23]],Polygon[{{-1,-1,-1},{ 1,-1,-3},{-1, 1,-3}}]}},
  Lighting -> OnlyAmbientLight, ViewPoint -> {5,4,4.5}, Boxed -> False]]]];
  ]

RotatePuzzle[f] := Module[{Temp},
   Temp = PColor[[1]];
   PColor[[1]] = PColor[[7]];
   PColor[[7]] = PColor[[13]];
   PColor[[13]] = Temp;
   Temp = PColor[[2]];
   PColor[[2]] = PColor[[8]];
   PColor[[8]] = PColor[[14]];
   PColor[[14]] = Temp;
   Temp = PColor[[6]];
   PColor[[6]] = PColor[[12]];
   PColor[[12]] = PColor[[18]];
   PColor[[18]] = Temp;
   ShowPuzzle
]
RotatePuzzle[b] := Module[{Temp},
   Temp = PColor[[2]];
   PColor[[2]] = PColor[[19]];
   PColor[[19]] = PColor[[10]];
   PColor[[10]] = Temp;
   Temp = PColor[[3]];
   PColor[[3]] = PColor[[20]];
   PColor[[20]] = PColor[[11]];
   PColor[[11]] = Temp;
   Temp = PColor[[4]];
   PColor[[4]] = PColor[[21]];
   PColor[[21]] = PColor[[12]];
   PColor[[12]] = Temp;
   ShowPuzzle;
]
RotatePuzzle[r] := Module[{Temp},
   Temp = PColor[[4]];
   PColor[[4]] = PColor[[14]];
   PColor[[14]] = PColor[[23]];
   PColor[[23]] = Temp;
   Temp = PColor[[5]];
   PColor[[5]] = PColor[[15]];
   PColor[[15]] = PColor[[24]];
   PColor[[24]] = Temp;
   Temp = PColor[[6]];
   PColor[[6]] = PColor[[16]];
   PColor[[16]] = PColor[[19]];
   PColor[[19]] = Temp;
   ShowPuzzle;
]
RotatePuzzle[l] := Module[{Temp},
   Temp = PColor[[8]];
   PColor[[8]] = PColor[[21]];
   PColor[[21]] = PColor[[16]];
   PColor[[16]] = Temp;
   Temp = PColor[[9]];
   PColor[[9]] = PColor[[22]];
   PColor[[22]] = PColor[[17]];
   PColor[[17]] = Temp;
   Temp = PColor[[10]];
   PColor[[10]] = PColor[[23]];
   PColor[[23]] = PColor[[18]];
   PColor[[18]] = Temp;
   ShowPuzzle;
]
ResetPuzzle := Module[{},
   PColor =
      {RGBColor[1,0,0],RGBColor[1,0,0],RGBColor[1,0,0],
       RGBColor[1,0,0],RGBColor[1,0,0],RGBColor[1,0,0],
       RGBColor[1,1,0],RGBColor[1,1,0],RGBColor[1,1,0],
       RGBColor[1,1,0],RGBColor[1,1,0],RGBColor[1,1,0],
       RGBColor[0,1,0],RGBColor[0,1,0],RGBColor[0,1,0],
       RGBColor[0,1,0],RGBColor[0,1,0],RGBColor[0,1,0],
       RGBColor[0,0,1],RGBColor[0,0,1],RGBColor[0,0,1],
       RGBColor[0,0,1],RGBColor[0,0,1],RGBColor[0,0,1]};
   Clear[f,r,l,b];
   ShowPuzzle;
]
PuzzlePosition1 := Module[{},
   PColor =
      {RGBColor[1,1,0],RGBColor[1,0,0],RGBColor[1,0,0],
       RGBColor[1,0,0],RGBColor[1,0,0],RGBColor[1,0,0],
       RGBColor[0,1,0],RGBColor[1,1,0],RGBColor[1,1,0],
       RGBColor[1,1,0],RGBColor[1,1,0],RGBColor[1,1,0],
       RGBColor[1,0,0],RGBColor[0,1,0],RGBColor[0,1,0],
       RGBColor[0,1,0],RGBColor[0,1,0],RGBColor[0,1,0],
       RGBColor[0,0,1],RGBColor[0,0,1],RGBColor[0,0,1],
       RGBColor[0,0,1],RGBColor[0,0,1],RGBColor[0,0,1]};
   ShowPuzzle;
]
PuzzlePosition2 := Module[{},
   PColor =
      {RGBColor[1,0,0],RGBColor[1,1,0],RGBColor[1,0,0],
       RGBColor[0,0,1],RGBColor[1,0,0],RGBColor[0,1,0],
       RGBColor[1,1,0],RGBColor[0,1,0],RGBColor[1,1,0],
       RGBColor[0,0,1],RGBColor[1,1,0],RGBColor[1,0,0],
       RGBColor[0,1,0],RGBColor[1,0,0],RGBColor[0,1,0],
       RGBColor[0,0,1],RGBColor[0,1,0],RGBColor[1,1,0],
       RGBColor[1,0,0],RGBColor[0,0,1],RGBColor[1,1,0],
       RGBColor[0,0,1],RGBColor[0,1,0],RGBColor[0,0,1]};
   ShowPuzzle;
]
HideCorners := Module[{},
   Off[Graphics3D::gprim];
   PColor[[ 1]] = PColor[[ 3]] = PColor[[ 5]] = 0;
   PColor[[ 7]] = PColor[[ 9]] = PColor[[11]] = 0;
   PColor[[13]] = PColor[[15]] = PColor[[17]] = 0;
   PColor[[20]] = PColor[[22]] = PColor[[24]] = 0;
   ShowPuzzle;
]
RotatePuzzle[DDot[x_, y_]] := Module[{},
   RotatePuzzle[x];
   RotatePuzzle[y]
]

Unfactorial[m_,n_] := Module[{Temp, index},
    index = 0;
    Temp = 1;
    While[(Temp < m)||(Temp < n), Temp *=(++index)];
    index
]
Unfactorial[n_] := Module[{Temp, index},
    index = 0;
    Temp = 1;
    While[Temp < n, Temp *=(++index)];
    index
]

NthPerm[n_Integer] := Module[{S, k, Temp, digit, u},
   u = Unfactorial[n];
   Temp = Table[u-i+1,{i,1,u}];
   S = P[];
   For[k=u, k>0, k--,
      digit = Quotient[Mod[n-1,k!],(k-1)!]+1;
      S = Prepend[S,Temp[[digit]] ];
      Temp = Delete[Temp, digit];
   ];
   S
]

NthPerm[n_Integer, u_Integer] := Module[{S, k, Temp, digit},
   Temp = Table[u-i+1,{i,1,u}];
   S = P[];
   For[k=u, k>0, k--,
      digit = Quotient[Mod[n-1,k!],(k-1)!]+1;
      S = Prepend[S,Temp[[digit]] ];
      Temp = Delete[Temp, digit];
   ];
   S
]

PermToInt[x_] := Module[{total,u,i,j},
   u = Length[x];
   total = 1;
   For[i=2,i<=u,i++,
     For[j=1,j<i,j++,
        If[x[[j]] > x[[i]], total += (i-1)!]
     ]
   ];
   total
]

Unprotect[P];

P::usage = "P[i, j, k, ...] denotes the permutation that sends 1 to i,
            2 to j, 3 to k, etc.";

P/: DDot[P[x___Integer], P[y___Integer]] :=
   Module[{ u, L, M, Temp, i},
      (* version where (f o g)(x) = g(f(x))
      L = P[y]; 
      M = P[x]; *)
      (* version where (f o g)(x) = f(g(x))  *)
      L = P[x]; 
      M = P[y];       
      u = Max[Length[L], Length[M]];
      For[ i = Length[L] + 1, i <= u, i++, AppendTo[L,i] ];
      For[ i = Length[M] + 1, i <= u, i++, AppendTo[M,i] ];
      Temp = L;
      For[ i = 1, i <= u, i++, Temp[[i]] = L[[M[[i]] ]] ];
      While[ Temp[[u]] == u, Temp = Delete[Temp,u]; u--];
      Temp
   ]

P/: P[x___Integer]^(-1) := Module[{ u, L, Temp, i },
   L = P[x];
   u = Length[L];
   Temp = L;
   For[ i = 1, i <= u, i++, Temp[[L[[i]] ]] = i];
   Temp
]

P/: P[x___Integer]^n_Integer := P[x] . (P[x]^(n-1)) /; n > 1;

P/: P[x___Integer]^n_Integer := DDot[P[x]^(-1), P[x]^(n+1)] /; n < -1;

PermMult::usage = "PermMult[x, y] takes the product of the x-th and y-th
                   permutations, and converts this back to an integer.";

PermMult[x_Integer, y_Integer] := Module[{ u, L, M, i},
   u = Unfactorial[x,y];
   (* version where (f o g)(x) = g(f(x))
   L = NthPerm[y,u]; 
   M = NthPerm[x,u];  *)
   (* version where (f o g)(x) = f(g(x))  *)     
   L = NthPerm[x,u]; 
   M = NthPerm[y,u];
   PermToInt[Table[L[[M[[i]]]],{i,1,u}] ]
]

InvPerm[x_Integer] := Module[{ u, L, M, i},
   u = Unfactorial[x];
   L = NthPerm[x,u];
   M = L;
   For[i=1,i<=u,i++, M[[L[[i]] ]] = i];
   PermToInt[M] ]

InitPermMultiplication := Module[{x, y},
   InitGroup[1];
   DDot[x_Integer, y_Integer] := PermMult[x,y];
   x_Integer ^(-1) := InvPerm[x] ]

Unprotect[OrderedQ];
Unprotect[Sort];
Unprotect[C];
ResetDot;

OrderedQ[{P[a___Integer],P[b___Integer]}] := Module[{i},
   If[Length[P[a]] > Length[P[b]], Return[False] ];
   If[Length[P[a]] < Length[P[b]], Return[True] ];
   For[i=Length[P[a]], i>0, i--,
      If[P[a][[i]] < P[b][[i]], Return[False] ];
      If[P[a][[i]] > P[b][[i]], Return[True] ] ];
   Return[True] ]

Sort[a_] := Sort[a, OrderedQ[{#1, #2}]&]

C::usage = "C[i, j, k, ...] denotes the cycle (ijk...).";

ClearAll[C];

C/: DDot[C[], z_]:= z

C/: DDot[z_, C[]] := z

C/: NumberQ[C[x$_]] := True

C[a__] := C[] /; Signature[{a}] == 0

C[a__] := (RotateRight[{a}] /. List -> C) /; Sort[{a}][[1]] =!= {a}[[1]]

C/: DDot[C[a__], C[b__]] := DDot[{b} /. List -> C, {a} /. List -> C] /;
   ( OrderedQ[{Sort[{b}][[1]], Sort[{a}][[1]] }]
                                 && Signature[{a,b}] =!= 0)

C/: DDot[DDot[z$_, C[a__]], C[b__]] :=
              DDot[DDot[z$, {b} /. List -> C], {a} /. List -> C] /;
   ( OrderedQ[{Sort[{b}][[1]], Sort[{a}][[1]] }]
                                 && Signature[{a,b}] =!= 0)

C/: C[a___]^(-1) := Reverse[C[a]] /; Length[{a}] =!= 1

DDot/: (DDot[C[a___], b_])^(-1) := DDot[b^(-1), (C[a])^(-1)];

PermToCycle[P[a___Integer]] := Module[{i, j, k, T, R, L},
   R = C[];
   T = P[a];
   For[i = 1, i < Length[T], i++,
      If[T[[i]] > 0,
         L = {i};
         j = T[[i]];
         T[[i]] = 0;
         While[T[[j]] > 0,
            AppendTo[L,j];
            k = j;
            j = T[[k]];
            T[[k]] = 0];
         If[Length[L] > 1, R = R . (L /. List -> C)] ] ];
   R ]

DotOut[R_List] := Module[{T,S,i,j},
   S = R;
   For[i = 1, i <= Length[S], i++,
      If[ S[[i]][[0]] === DDot,
         T = S[[i]];
         S = Delete[S,i];
         For[j = Length[T],j > 0,j--,
            S = Insert[S,T[[j]],i] ];
         i-- ] ];
   S ]

C/: DDot[a__,C[b__]] := Module[{S, T, R, L, i, j, k},
   S = DotOut[{a,C[b]} /. P[x$__] -> PermToCycle[P[x$]] ];
   T = Union[Flatten[ S /. C -> List]];
   R = C[];
   For[i = 1, i < Length[T], i++,
      If[T[[i]] =!= Null,
         L = {};
         j = T[[i]];
         While[ MemberQ[T,j],
            AppendTo[L,j];
            T[[Position[T,j,1][[1]][[1]] ]] = Null;
            (* version where (f o g)(x) = g(f(x))
            For[ k = 1, k <= Length[S], k++, *)
            (* version where (f o g)(x) = f(g(x))  *)
            For[ k = Length[S], k >= 1, k--,
               If[ MemberQ[S[[k]],j],
   j = S[[k]][[Mod[Position[S[[k]],j,1][[1]][[1]],Length[S[[k]]]]+1]]
                 ]
               ]
            ];
         If[Length[L] > 1, R = DDot[R, L /. List -> C] ] ] ];
   R ] /;
     (Signature[Flatten[DotOut[{a,C[b]}],1,C] ] === 0) &&
     (Length[{b}] > 1)

C[a___][b_] := If[MemberQ[{a},b],
     {a}[[Mod[Position[{a},b,1][[1]][[1]],Length[{a}]]+1]],
     b ]

P[a___Integer][b_] := If[ b>0 && b <= Length[{a}],
    P[a][[b]],b,b]

P/: DDot[C[a___], P[b___]] := DDot[C[a], PermToCycle[P[b]]]

P/: DDot[DDot[z$_,C[a___]],P[b___]] := DDot[DDot[z$, C[a]], PermToCycle[P[b]]]

C/: DDot[P[a___], C[b___]] := DDot[PermToCycle[P[a]], C[b]]

C/: DDot[DDot[z$_,P[a___]],C[b___]] := DDot[DDot[z$, PermToCycle[P[a]]], C[b]]

CycleToPerm[C[]] := P[]

CycleToPerm[C[a__Integer]] := Module[{L,R,i },
   L = {a};
   R = Table[i,{i,Max[L]}];
   For[i=1,i<Length[L],i++,
     R[[L[[i]]]] = L[[i+1]] ];
   R[[L[[-1]]]] = L[[1]];
   Return[R /. List -> P ] ] /; Min[a] > 0

CycleToPerm[DDot[C[a___Integer], b_]] :=
               DDot[CycleToPerm[C[a]], CycleToPerm[b]]
CycleToPerm[DDot[a_, C[b___Integer]]] :=
               DDot[CycleToPerm[a], CycleToPerm[C[b]]]
ShowRationals[a_,b_] := Module[{p,q,A,B,r,QuoList,PrintPoint},
   A = N[a];
   B = N[b];
   If[ B === A,
     Print["Endpoints Must be different."],
     If[ B < A,
       q = A;
       A = B;
       B = q];
     QuoList = {};
     r=1;
     For[q = 1, r <= 16 ,q++,
        PrintPoint = False;
        For[p= Ceiling[A q], p <= B q,p++,
           If[GCD[p,q] === 1,
              AppendTo[QuoList,Point[{p/q,(.75)^(r-1)}]];
              PrintPoint = True;
             ]
            ];
        If[PrintPoint, r++]];
   Show[Graphics[QuoList],
   Prolog -> {AbsolutePointSize[2],AbsoluteThickness[1]},
   Axes -> {True,False}, AxesOrigin -> {0,0},
   PlotRange -> All,AspectRatio -> 1/2]
   ]
]

CountableQ[n_Integer] :=  Module[{p,q,NN,LineList},
   NN = Abs[n];
   If[NN === 0, NN = 1];
   LineList = {};
   For[q = 1, q <= 16 ,q++,
      For[p= -NN q, p <= NN q,p++,
        If[GCD[p,q] === 1,
          AppendTo[LineList,Point[{p/q,(.75)^(q-1)}]]]]];
   For[q = - Floor[NN/2], 2 q <= NN-1, q++,
      AppendTo[LineList,Line[{{2 q,1},{2 q + 1,1}}]]];
   For[q = 1, q <= NN, q++,
      AppendTo[LineList,Line[{{q-.5,.75},{q,1}}]];
      AppendTo[LineList,Line[{{-q+.5,.75},{-q,1}}]];
      AppendTo[LineList,
         Line[{{-1/(q+1),(.75)^q},{1/(q+1),(.75)^q}}]]];
   For[p = 1, p <= NN-1, p++,
      For[q = 2, q <= NN-p+1, q++,
         AppendTo[LineList,
              Line[{{p+1/(q+1)-1,(.75)^q},
                    {p-1/(q+1),(.75)^q},
                    {p+1/q,(.75)^(q-1)}}]];
         AppendTo[LineList,
              Line[{{1-p-1/(q+1),(.75)^q},
                    {1/(q+1)-p,(.75)^q},
                    {-p-1/q,(.75)^(q-1)}}]]]];
   Show[Graphics[LineList],
   Prolog -> {AbsolutePointSize[2],AbsoluteThickness[1]},
   Axes -> {True,False}, AxesOrigin -> {0,0},
   PlotRange -> All,AspectRatio -> 1/2]
]
               
Protect[OrderedQ, Sort, C, P, Dot, Intersection];

Print["Initialization Done"];
